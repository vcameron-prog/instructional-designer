# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **AI**: OpenAI via Replit AI Integrations (gpt-5-mini)
- **Frontend**: React + Vite + TailwindCSS + React Query

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── pdf-accessibility/  # React+Vite frontend (BSU PDF Title II Remediation)
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   ├── db/                 # Drizzle ORM schema + DB connection
│   └── integrations/       # Replit AI integrations (OpenAI)
├── scripts/                # Utility scripts (single workspace package)
│   └── src/                # Individual .ts scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## App: BSU PDF Title II Remediation

Full-stack app that converts uploaded PDFs into accessible HTML documents meeting ADA Title II / WCAG 2.1 Level AA requirements.

### Features
- Drag-and-drop PDF upload (up to 20MB)
- AI-powered document remediation using OpenAI (gpt-5-mini)
- OCR support for scanned PDFs using GPT-4o vision API (auto-detects low-text PDFs)
- WCAG compliance reports with before/after scores (original PDF vs. converted HTML)
- Accessible HTML preview and download (HTML and DOCX)
- Manual HTML editing with Preview/Edit toggle (compliance score not re-evaluated on manual edit)
- Auto-start remediation after upload (no manual button click needed)

### Frontend Routes
- `/` — Home page with upload dropzone (login prompt when unauthenticated)
- `/history` — Conversion history with document list, search, delete
- `/conversion/:id` — Conversion detail with compliance report, HTML preview, download, and "Convert Another" button
- `/faq` — Frequently Asked Questions with expandable accordion sections
- `/admin` — Admin dashboard (admin-only, protected by ADMIN_USER_IDS env var)

### Authentication
- Replit Auth (OpenID Connect with PKCE) via `@workspace/replit-auth-web`
- Login/logout UI in header with user avatar and name
- All pages show login prompt when unauthenticated
- All API routes require authentication (401 for unauthenticated)
- Conversions are tied to the logged-in user via userId

### API Endpoints (mounted at `/api`)
- `GET /api/auth/user` — Get current authenticated user
- `GET /api/login` — Initiate OIDC login flow
- `GET /api/callback` — OIDC callback
- `GET /api/logout` — Logout and end session
- `GET /api/conversions` — List user's conversions (auth required)
- `POST /api/conversions` — Upload PDF (auth required)
- `GET /api/conversions/:id` — Get conversion details (auth + ownership required)
- `POST /api/conversions/:id/process` — Start AI remediation (auth + ownership required)
- `GET /api/conversions/:id/download` — Download accessible HTML (auth + ownership required)
- `DELETE /api/conversions/:id` — Delete conversion (auth + ownership required)
- `POST /api/conversions/:id/fix-issue` — Fix a specific compliance issue with AI (auth + ownership required)
- `GET /api/admin/check` — Check if current user is admin (returns `{ isAdmin: false }` when unauthenticated)
- `GET /api/admin/users` — List all users with conversion counts (admin only)
- `GET /api/admin/stats` — Get total users, conversions, and monthly usage charts (admin only)

### Database Schema
- `users` table: id, email, first_name, last_name, profile_image_url, created_at, updated_at
- `sessions` table: sid, sess (JSONB), expire
- `conversions` table: id, original_filename, file_size, status (uploaded/processing/completed/failed), page_count, extracted_text, accessible_html, compliance_report (JSONB), original_compliance_report (JSONB), error_message, pdf_data (base64), ocr_applied (boolean), user_id (FK to users), created_at, updated_at

### Key Implementation Details
- OCR detection: if extracted text has < 50 chars/page, the PDF is considered a scanned document
- OCR uses GPT-4o vision API to extract text from page images (batches of 4 pages)
- PDF text extraction uses `pdf-parse` (ESM-compatible import via default fallback)
- AI remediation via `@workspace/integrations-openai-ai-server` (Replit AI Integrations proxy)
- Environment vars: `AI_INTEGRATIONS_OPENAI_BASE_URL`, `AI_INTEGRATIONS_OPENAI_API_KEY` (auto-set), `ADMIN_USER_IDS` (comma-separated list of user IDs for admin access)
- Frontend download uses direct `fetch` to `/api/conversions/:id/download` (returns HTML, not JSON)
- Frontend polls every 3 seconds when conversion status is `processing`

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json` which sets `composite: true`. The root `tsconfig.json` lists all packages as project references. This means:

- **Always typecheck from the root** — run `pnpm run typecheck`
- **`emitDeclarationOnly`** — only emit `.d.ts` files during typecheck
- **Project references** — when package A depends on package B, A's `tsconfig.json` must list B in its `references` array

## Root Scripts

- `pnpm run build` — runs `typecheck` first, then recursively runs `build` in all packages
- `pnpm run typecheck` — runs `tsc --build --emitDeclarationOnly` using project references

## Packages

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server with PDF conversion routes and AI integration.

- Entry: `src/index.ts` — reads `PORT`, starts Express
- Routes: `src/routes/conversions.ts` — all PDF conversion CRUD + processing
- AI Engine: `src/lib/accessibility-engine.ts` — OpenAI-powered WCAG remediation
- PDF Processor: `src/lib/pdf-processor.ts` — PDF text extraction via pdf-parse
- Auth: `src/lib/auth.ts` (session CRUD, OIDC config), `src/middlewares/authMiddleware.ts`, `src/routes/auth.ts`
- Dependencies: `@workspace/db`, `@workspace/api-zod`, `@workspace/integrations-openai-ai-server`, `multer`, `pdf-parse`, `openid-client`, `cookie-parser`

### `artifacts/pdf-accessibility` (`@workspace/pdf-accessibility`)

React + Vite frontend for BSU PDF Title II Remediation.

- Pages: Home (upload), History, ConversionDetail, FAQ
- Custom hooks in `src/hooks/use-conversions.ts` wrap generated API hooks
- Components: Layout, UploadDropzone, StatusBadge, ComplianceChart
- Dependencies: `@workspace/api-client-react`, `@workspace/replit-auth-web`, `wouter`, `framer-motion`, `lucide-react`, `date-fns`

### `lib/db` (`@workspace/db`)

Database layer using Drizzle ORM with PostgreSQL.

- Schema: `src/schema/conversions.ts` — conversions table, `src/schema/auth.ts` — users + sessions tables
- Push schema: `pnpm --filter @workspace/db run push`

### `lib/api-spec` (`@workspace/api-spec`)

OpenAPI 3.1 spec and Orval codegen config.

- Run codegen: `pnpm --filter @workspace/api-spec run codegen`

### `lib/api-zod` (`@workspace/api-zod`)

Generated Zod schemas from OpenAPI spec.

### `lib/api-client-react` (`@workspace/api-client-react`)

Generated React Query hooks and fetch client from OpenAPI spec.

### `lib/replit-auth-web` (`@workspace/replit-auth-web`)

Browser auth package providing `useAuth()` hook for login/logout/user state.

### `scripts` (`@workspace/scripts`)

Utility scripts. Run via `pnpm --filter @workspace/scripts run <script>`.
