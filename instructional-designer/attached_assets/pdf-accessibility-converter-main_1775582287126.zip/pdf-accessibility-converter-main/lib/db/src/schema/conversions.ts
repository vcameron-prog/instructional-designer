import { pgTable, text, serial, integer, timestamp, jsonb, varchar, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./auth";

export const conversionsTable = pgTable("conversions", {
  id: serial("id").primaryKey(),
  originalFilename: text("original_filename").notNull(),
  fileSize: integer("file_size").notNull(),
  status: text("status").notNull().default("uploaded"),
  pageCount: integer("page_count"),
  extractedText: text("extracted_text"),
  accessibleHtml: text("accessible_html"),
  complianceReport: jsonb("compliance_report"),
  originalComplianceReport: jsonb("original_compliance_report"),
  errorMessage: text("error_message"),
  pdfData: text("pdf_data"),
  ocrApplied: boolean("ocr_applied").notNull().default(false),
  userId: varchar("user_id").references(() => usersTable.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertConversionSchema = createInsertSchema(conversionsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertConversion = z.infer<typeof insertConversionSchema>;
export type Conversion = typeof conversionsTable.$inferSelect;
