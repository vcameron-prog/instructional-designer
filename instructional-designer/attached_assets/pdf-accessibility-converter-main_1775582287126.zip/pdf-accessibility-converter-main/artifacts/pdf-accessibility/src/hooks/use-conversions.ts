import { useQueryClient, useQuery } from "@tanstack/react-query";
import {
  useListConversions,
  useUploadPdf,
  useGetConversion,
  useProcessConversion,
  useDeleteConversion,
  useFixComplianceIssue,
  useAcceptComplianceIssue,
  useRevertComplianceIssue,
  useUpdateConversionHtml,
  getListConversionsQueryKey,
  getGetConversionQueryKey,
  getGetConversionQueryOptions
} from "@workspace/api-client-react";

export function useAppConversions() {
  return useListConversions();
}

export function useAppConversion(id: number) {
  const queryOptions = getGetConversionQueryOptions(id);
  return useQuery({
    ...queryOptions,
    enabled: !!id,
    refetchInterval: (query) =>
      query.state.data?.status === "processing" ? 3000 : false,
  });
}

export function useAppUploadPdf() {
  const queryClient = useQueryClient();
  return useUploadPdf({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListConversionsQueryKey() });
      }
    }
  });
}

export function useAppProcessConversion() {
  const queryClient = useQueryClient();
  return useProcessConversion({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListConversionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetConversionQueryKey(data.id) });
      }
    }
  });
}

export function useAppDeleteConversion() {
  const queryClient = useQueryClient();
  return useDeleteConversion({
    mutation: {
      onSuccess: (_, variables) => {
        queryClient.invalidateQueries({ queryKey: getListConversionsQueryKey() });
        queryClient.removeQueries({ queryKey: getGetConversionQueryKey(variables.id) });
      }
    }
  });
}

export function useAppFixIssue() {
  const queryClient = useQueryClient();
  return useFixComplianceIssue({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getGetConversionQueryKey(data.id) });
      }
    }
  });
}

export function useAppAcceptIssue() {
  const queryClient = useQueryClient();
  return useAcceptComplianceIssue({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getGetConversionQueryKey(data.id) });
      }
    }
  });
}

export function useAppRevertIssue() {
  const queryClient = useQueryClient();
  return useRevertComplianceIssue({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getGetConversionQueryKey(data.id) });
      }
    }
  });
}

export function useAppUpdateHtml() {
  const queryClient = useQueryClient();
  return useUpdateConversionHtml({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getGetConversionQueryKey(data.id) });
      }
    }
  });
}
