import { useQuery } from "@tanstack/react-query";

interface AdminUser {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  createdAt: string;
  conversionCount: number;
}

interface AdminStats {
  totalUsers: number;
  totalConversions: number;
  signupsByMonth: { month: string; count: number }[];
  conversionsByMonth: { month: string; count: number }[];
}

async function fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error((body as { error?: string }).error || `HTTP ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export function useAdminCheck() {
  return useQuery({
    queryKey: ["admin", "check"],
    queryFn: () => fetchJson<{ isAdmin: boolean }>("/api/admin/check"),
    staleTime: 5 * 60 * 1000,
  });
}

export function useAdminUsers(enabled = true) {
  return useQuery({
    queryKey: ["admin", "users"],
    queryFn: () => fetchJson<{ users: AdminUser[] }>("/api/admin/users"),
    enabled,
  });
}

export function useAdminStats(enabled = true) {
  return useQuery({
    queryKey: ["admin", "stats"],
    queryFn: () => fetchJson<AdminStats>("/api/admin/stats"),
    enabled,
  });
}

export type { AdminUser, AdminStats };
