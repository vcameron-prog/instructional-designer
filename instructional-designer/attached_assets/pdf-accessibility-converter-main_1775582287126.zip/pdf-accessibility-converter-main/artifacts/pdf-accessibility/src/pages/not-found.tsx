import { Layout } from "@/components/Layout";
import { AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <Layout>
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <AlertCircle className="h-12 w-12 text-destructive mb-4" aria-hidden="true" />
        <h1 className="text-2xl font-bold text-foreground">404 Page Not Found</h1>
        <p className="mt-3 text-muted-foreground max-w-md">
          The page you are looking for does not exist or has been moved.
        </p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 mt-6 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-bold shadow-md shadow-primary/20 hover:-translate-y-0.5 transition-all"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          Go Home
        </Link>
      </div>
    </Layout>
  );
}
