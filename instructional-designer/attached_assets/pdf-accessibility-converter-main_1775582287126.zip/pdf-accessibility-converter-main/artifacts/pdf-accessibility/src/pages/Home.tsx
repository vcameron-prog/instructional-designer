import { useLocation } from "wouter";
import { Layout } from "@/components/Layout";
import { UploadDropzone } from "@/components/UploadDropzone";
import { useAppUploadPdf } from "@/hooks/use-conversions";
import { useAuth } from "@workspace/replit-auth-web";
import { motion } from "framer-motion";
import { ShieldAlert, BookOpenCheck, BrainCircuit, LogIn, Loader2 } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const uploadMutation = useAppUploadPdf();
  const { isAuthenticated, isLoading, login } = useAuth();

  const handleUpload = async (file: File) => {
    uploadMutation.mutate({ data: { file } }, {
      onSuccess: (data) => {
        setLocation(`/conversion/${data.id}`);
      }
    });
  };

  return (
    <Layout>
      <div className="flex flex-col items-center py-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-3xl mb-12 space-y-4"
        >
          <h1 className="text-4xl md:text-5xl font-black text-foreground tracking-tight">
            Make Documents <span className="text-primary bg-primary/10 px-2 rounded-lg">Accessible</span>
          </h1>
          <p className="text-lg text-muted-foreground font-medium">
            Instantly remediate PDF documents to meet ADA Title II and WCAG 2.1 AA requirements using advanced AI structural analysis and description generation.
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="w-full"
        >
          {isLoading ? (
            <div className="flex items-center justify-center py-20" role="status" aria-live="polite">
              <Loader2 className="w-8 h-8 animate-spin text-primary" aria-hidden="true" />
              <span className="sr-only">Loading...</span>
            </div>
          ) : !isAuthenticated ? (
            <div className="bg-card border-2 border-dashed border-border rounded-3xl p-12 text-center">
              <LogIn className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-60" aria-hidden="true" />
              <h2 className="text-xl font-bold text-foreground mb-2">Log in to get started</h2>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Please log in to upload and convert PDF documents for accessibility remediation.
              </p>
              <button
                onClick={login}
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-bold shadow-md shadow-primary/20 hover:-translate-y-0.5 transition-all"
              >
                <LogIn className="w-5 h-5" aria-hidden="true" />
                Log in
              </button>
            </div>
          ) : (
            <UploadDropzone 
              onUpload={handleUpload} 
              isUploading={uploadMutation.isPending} 
            />
          )}
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl mt-20"
        >
          <div className="bg-card p-6 rounded-2xl border shadow-sm flex flex-col items-center text-center space-y-4">
            <div className="bg-primary/10 p-3 rounded-full text-primary">
              <ShieldAlert className="w-8 h-8" aria-hidden="true" />
            </div>
            <h3 className="font-bold text-lg">Title II Compliant</h3>
            <p className="text-sm text-muted-foreground">Ensures your documents meet the rigorous standards required for state and local governments.</p>
          </div>
          
          <div className="bg-card p-6 rounded-2xl border shadow-sm flex flex-col items-center text-center space-y-4">
            <div className="bg-blue-500/10 p-3 rounded-full text-blue-600 dark:text-blue-400">
              <BrainCircuit className="w-8 h-8" aria-hidden="true" />
            </div>
            <h3 className="font-bold text-lg">AI Alt Text</h3>
            <p className="text-sm text-muted-foreground">Automatically detects images and charts, generating accurate semantic alternative text descriptions.</p>
          </div>

          <div className="bg-card p-6 rounded-2xl border shadow-sm flex flex-col items-center text-center space-y-4">
            <div className="bg-violet-500/10 p-3 rounded-full text-violet-600 dark:text-violet-400">
              <BookOpenCheck className="w-8 h-8" aria-hidden="true" />
            </div>
            <h3 className="font-bold text-lg">Reading Order</h3>
            <p className="text-sm text-muted-foreground">Restructures complex multi-column layouts into a linear, logical reading order for screen readers.</p>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
