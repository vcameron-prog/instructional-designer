import { useState, useMemo } from "react";
import { format } from "date-fns";
import { Users, FileText, ArrowUpDown, ShieldAlert, Loader2, User } from "lucide-react";
import { Layout } from "@/components/Layout";
import { useAuth } from "@workspace/replit-auth-web";
import { useAdminUsers, useAdminStats, useAdminCheck } from "@/hooks/use-admin";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

type SortField = "createdAt" | "conversionCount";
type SortDir = "asc" | "desc";

export default function Admin() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { data: adminCheck, isLoading: adminCheckLoading } = useAdminCheck();
  const isAdmin = isAuthenticated && adminCheck?.isAdmin === true;
  const { data: usersData, isLoading: usersLoading, isError: usersError } = useAdminUsers(isAdmin);
  const { data: stats, isLoading: statsLoading, isError: statsError } = useAdminStats(isAdmin);

  const [sortField, setSortField] = useState<SortField>("createdAt");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("desc");
    }
  };

  const sortedUsers = useMemo(() => {
    if (!usersData?.users) return [];
    const sorted = [...usersData.users];
    sorted.sort((a, b) => {
      let cmp: number;
      if (sortField === "createdAt") {
        cmp = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      } else {
        cmp = a.conversionCount - b.conversionCount;
      }
      return sortDir === "asc" ? cmp : -cmp;
    });
    return sorted;
  }, [usersData, sortField, sortDir]);

  const chartData = useMemo(() => {
    if (!stats) return [];
    const monthSet = new Set<string>();
    stats.signupsByMonth.forEach((s) => monthSet.add(s.month));
    stats.conversionsByMonth.forEach((c) => monthSet.add(c.month));
    const months = Array.from(monthSet).sort();

    const signupsMap = Object.fromEntries(stats.signupsByMonth.map((s) => [s.month, s.count]));
    const conversionsMap = Object.fromEntries(stats.conversionsByMonth.map((c) => [c.month, c.count]));

    return months.map((month) => ({
      month: format(new Date(month + "-01"), "MMM yyyy"),
      signups: signupsMap[month] || 0,
      conversions: conversionsMap[month] || 0,
    }));
  }, [stats]);

  if (authLoading || adminCheckLoading) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center py-20" role="status">
          <Loader2 className="w-8 h-8 animate-spin text-primary mb-4" aria-hidden="true" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </Layout>
    );
  }

  if (!isAuthenticated || !isAdmin) {
    return (
      <Layout>
        <div className="bg-card border border-border rounded-3xl p-16 text-center shadow-sm">
          <ShieldAlert className="w-16 h-16 mx-auto text-destructive mb-4 opacity-70" aria-hidden="true" />
          <h1 className="text-2xl font-bold text-foreground">Access Denied</h1>
          <p className="text-muted-foreground mt-2 max-w-md mx-auto">
            You do not have permission to view this page. Only administrators can access the dashboard.
          </p>
        </div>
      </Layout>
    );
  }

  const isLoading = usersLoading || statsLoading;

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-black">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Overview of users and conversion activity.
          </p>
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20" role="status">
            <Loader2 className="w-8 h-8 animate-spin text-primary mb-4" aria-hidden="true" />
            <p className="text-muted-foreground">Loading dashboard data...</p>
          </div>
        ) : usersError || statsError ? (
          <div className="bg-destructive/10 border border-destructive/20 text-destructive p-6 rounded-2xl text-center" role="alert">
            <p className="font-bold">Failed to load dashboard data</p>
            <p className="text-sm mt-1">Please try refreshing the page.</p>
          </div>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-5 w-5 text-muted-foreground" aria-hidden="true" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{stats?.totalUsers ?? 0}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Conversions</CardTitle>
                  <FileText className="h-5 w-5 text-muted-foreground" aria-hidden="true" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{stats?.totalConversions ?? 0}</div>
                </CardContent>
              </Card>
            </div>

            {chartData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Usage Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                        <XAxis
                          dataKey="month"
                          className="text-xs fill-muted-foreground"
                          tick={{ fontSize: 12 }}
                        />
                        <YAxis
                          className="text-xs fill-muted-foreground"
                          tick={{ fontSize: 12 }}
                          allowDecimals={false}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--card))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "0.75rem",
                            fontSize: 13,
                          }}
                        />
                        <Legend />
                        <Bar
                          dataKey="signups"
                          name="Signups"
                          fill="hsl(var(--primary))"
                          radius={[4, 4, 0, 0]}
                        />
                        <Bar
                          dataKey="conversions"
                          name="Conversions"
                          fill="hsl(262 83% 58%)"
                          radius={[4, 4, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Registered Users</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[60px]">Avatar</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>
                        <button
                          onClick={() => toggleSort("createdAt")}
                          className="inline-flex items-center gap-1 font-medium hover:text-foreground transition-colors"
                          aria-label="Sort by signup date"
                        >
                          Signup Date
                          <ArrowUpDown className="h-3.5 w-3.5" aria-hidden="true" />
                          {sortField === "createdAt" && (
                            <span className="text-xs text-primary">
                              {sortDir === "asc" ? "↑" : "↓"}
                            </span>
                          )}
                        </button>
                      </TableHead>
                      <TableHead>
                        <button
                          onClick={() => toggleSort("conversionCount")}
                          className="inline-flex items-center gap-1 font-medium hover:text-foreground transition-colors"
                          aria-label="Sort by conversion count"
                        >
                          Conversions
                          <ArrowUpDown className="h-3.5 w-3.5" aria-hidden="true" />
                          {sortField === "conversionCount" && (
                            <span className="text-xs text-primary">
                              {sortDir === "asc" ? "↑" : "↓"}
                            </span>
                          )}
                        </button>
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedUsers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No users registered yet.
                        </TableCell>
                      </TableRow>
                    ) : (
                      sortedUsers.map((u) => (
                        <TableRow key={u.id}>
                          <TableCell>
                            {u.profileImageUrl ? (
                              <img
                                src={u.profileImageUrl}
                                alt={`${u.firstName || "User"}'s avatar`}
                                className="w-8 h-8 rounded-full object-cover border border-border"
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                                <User className="w-4 h-4" aria-hidden="true" />
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="font-medium">
                            {[u.firstName, u.lastName].filter(Boolean).join(" ") || "—"}
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {u.email || "—"}
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            <time dateTime={new Date(u.createdAt).toISOString()}>
                              {format(new Date(u.createdAt), "MMM d, yyyy")}
                            </time>
                          </TableCell>
                          <TableCell>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-primary/10 text-primary">
                              {u.conversionCount}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </Layout>
  );
}
