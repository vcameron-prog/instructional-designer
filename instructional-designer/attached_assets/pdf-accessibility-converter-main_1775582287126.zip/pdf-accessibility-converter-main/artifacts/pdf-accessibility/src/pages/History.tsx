import { Link } from "wouter";
import { format } from "date-fns";
import { File, ArrowRight, Trash2, Search, Loader2, LogIn, Upload, Info } from "lucide-react";
import { Layout } from "@/components/Layout";
import { StatusBadge } from "@/components/StatusBadge";
import { useAppConversions, useAppDeleteConversion } from "@/hooks/use-conversions";
import { useAuth } from "@workspace/replit-auth-web";
import { formatBytes } from "@/lib/utils";
import { motion } from "framer-motion";

export default function History() {
  const { isAuthenticated, isLoading: authLoading, login } = useAuth();
  const { data: conversions, isLoading, isError } = useAppConversions();
  const deleteMutation = useAppDeleteConversion();

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    if (window.confirm("Are you sure you want to delete this conversion record?")) {
      deleteMutation.mutate({ id });
    }
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-black">Conversion History</h1>
            <p className="text-muted-foreground mt-1">Review and manage your remediated documents.</p>
          </div>
          
          {isAuthenticated && (
            <div className="flex items-center gap-3 w-full sm:w-auto">
              {conversions && conversions.length > 0 && (
                <Link
                  href="/"
                  className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl font-bold text-sm shadow-md shadow-primary/20 hover:-translate-y-0.5 transition-all whitespace-nowrap"
                >
                  <Upload className="w-4 h-4" aria-hidden="true" />
                  Upload Another File
                </Link>
              )}
              <div className="relative flex-1 sm:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
                <label htmlFor="search-documents" className="sr-only">Search documents</label>
                <input 
                  id="search-documents"
                  type="text" 
                  placeholder="Search documents..." 
                  className="w-full pl-9 pr-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-shadow shadow-sm"
                  disabled={isLoading || isError}
                />
              </div>
            </div>
          )}
        </div>

        {isAuthenticated && (
          <div className="flex items-start gap-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-2xl p-4" role="note" aria-label="Title II review reminder">
            <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" aria-hidden="true" />
            <p className="text-sm text-blue-800 dark:text-blue-200 font-medium">
              <span className="font-bold">Reminder:</span> Review the output for accuracy and double check that the components of Title II remediation are accounted for.
            </p>
          </div>
        )}

        {!authLoading && !isAuthenticated ? (
          <div className="bg-card border border-border rounded-3xl p-16 text-center shadow-sm">
            <LogIn className="w-16 h-16 mx-auto text-muted-foreground mb-4 opacity-50" aria-hidden="true" />
            <h2 className="text-xl font-bold text-foreground">Log in to view your history</h2>
            <p className="text-muted-foreground mt-2 max-w-md mx-auto mb-8">
              Please log in to see your conversion history and manage your documents.
            </p>
            <button
              onClick={login}
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-bold shadow-md shadow-primary/20 hover:-translate-y-0.5 transition-all"
            >
              <LogIn className="w-5 h-5" aria-hidden="true" />
              Log in
            </button>
          </div>
        ) : isLoading || authLoading ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground" role="status" aria-live="polite">
            <Loader2 className="w-8 h-8 animate-spin text-primary mb-4" aria-hidden="true" />
            <p>Loading your history...</p>
          </div>
        ) : isError ? (
          <div className="bg-destructive/10 border border-destructive/20 text-destructive p-6 rounded-2xl text-center" role="alert">
            <p className="font-bold">Failed to load conversions</p>
            <p className="text-sm mt-1">Please try refreshing the page.</p>
          </div>
        ) : !conversions || conversions.length === 0 ? (
          <div className="bg-card border border-border rounded-3xl p-16 text-center shadow-sm">
            <File className="w-16 h-16 mx-auto text-muted-foreground mb-4 opacity-50" aria-hidden="true" />
            <h2 className="text-xl font-bold text-foreground">No documents yet</h2>
            <p className="text-muted-foreground mt-2 max-w-md mx-auto mb-8">
              You haven't uploaded any PDF documents for accessibility remediation yet.
            </p>
            <Link 
              href="/" 
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-bold shadow-md shadow-primary/20 hover:-translate-y-0.5 transition-all"
            >
              Upload a Document
            </Link>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto" tabIndex={0} role="region" aria-label="Conversion history table">
              <table className="w-full text-left text-sm whitespace-nowrap">
                <caption className="sr-only">List of uploaded PDF documents and their conversion status</caption>
                <thead className="bg-secondary/50 text-muted-foreground border-b border-border">
                  <tr>
                    <th scope="col" className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Document</th>
                    <th scope="col" className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Status</th>
                    <th scope="col" className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Size & Pages</th>
                    <th scope="col" className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Date</th>
                    <th scope="col" className="px-6 py-4 font-semibold uppercase tracking-wider text-xs text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {conversions.map((conv, i) => (
                    <motion.tr 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      key={conv.id} 
                      className="hover:bg-secondary/20 transition-colors group"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-violet-500/10 text-violet-600 dark:text-violet-400" aria-hidden="true">
                            <File className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="font-bold text-foreground truncate max-w-[250px] sm:max-w-[350px]">
                              {conv.originalFilename}
                            </p>
                            <p className="text-xs text-muted-foreground">ID: {conv.id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <StatusBadge status={conv.status === 'completed' && conv.complianceScore !== null && conv.complianceScore < 100 ? 'review' : conv.status} />
                      </td>
                      <td className="px-6 py-4 text-muted-foreground">
                        {formatBytes(conv.fileSize)}
                        {conv.pageCount && <span className="ml-2 px-2 py-0.5 bg-secondary text-secondary-foreground rounded-md text-xs">{conv.pageCount} pages</span>}
                      </td>
                      <td className="px-6 py-4 text-muted-foreground">
                        <time dateTime={new Date(conv.createdAt).toISOString()}>
                          {format(new Date(conv.createdAt), "MMM d, yyyy h:mm a")}
                        </time>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={(e) => handleDelete(e, conv.id)}
                            className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                            aria-label={`Delete ${conv.originalFilename}`}
                          >
                            <Trash2 className="w-4 h-4" aria-hidden="true" />
                          </button>
                          <Link 
                            href={`/conversion/${conv.id}`}
                            className="inline-flex items-center gap-1.5 px-4 py-2 bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground rounded-lg font-semibold transition-all group-hover:shadow-sm"
                            aria-label={`View details for ${conv.originalFilename}`}
                          >
                            View
                            <ArrowRight className="w-4 h-4" aria-hidden="true" />
                          </Link>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
