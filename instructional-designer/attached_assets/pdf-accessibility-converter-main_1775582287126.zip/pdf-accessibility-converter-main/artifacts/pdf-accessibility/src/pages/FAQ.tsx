import { useState } from "react";
import { Layout } from "@/components/Layout";
import { ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface FAQItem {
  question: string;
  answer: string | string[];
}

interface FAQSection {
  title: string;
  items: FAQItem[];
}

const FAQ_SECTIONS: FAQSection[] = [
  {
    title: "Getting Started",
    items: [
      {
        question: "What does this tool do?",
        answer: "This tool converts PDF documents into accessible HTML files that meet ADA Title II and WCAG 2.1 Level AA requirements. It uses AI to analyze your document's structure, add proper headings, image descriptions, reading order, and other accessibility features.",
      },
      {
        question: "Who is this tool for?",
        answer: "This tool is designed for BSU faculty and staff who need to make their course materials and documents accessible to all students, including those who use screen readers or other assistive technologies.",
      },
      {
        question: "Do I need any technical skills to use this?",
        answer: "No. Simply log in, drag and drop your PDF, and the tool handles the rest. You'll get a downloadable Word document or HTML file that's ready to share with students.",
      },
      {
        question: "What file types can I upload?",
        answer: "Currently, the tool accepts PDF files only. If you have documents in other formats (Word, PowerPoint, etc.), save them as PDF first, then upload the PDF here.",
      },
    ],
  },
  {
    title: "Accessibility & Compliance",
    items: [
      {
        question: "What is ADA Title II compliance?",
        answer: "ADA Title II requires that state and local government entities, including public universities like BSU, make their services and programs accessible to people with disabilities. This includes digital documents shared with students.",
      },
      {
        question: "What is WCAG 2.1 Level AA?",
        answer: "WCAG (Web Content Accessibility Guidelines) is a set of standards for making web content accessible. Level AA is the standard most organizations are expected to meet. It covers things like text alternatives for images, proper document structure, readable text, and keyboard navigation.",
      },
      {
        question: "What does the compliance score mean?",
        answer: [
          "The compliance score shows how well your converted document meets accessibility standards. It checks for:",
          "• Image Descriptions — Do all images have meaningful descriptions?",
          "• Document Structure — Are headings, lists, and sections properly organized?",
          "• Reading Order — Does the content flow logically for screen readers?",
          "• Table Headers — Do data tables have proper header labels?",
          "• Text Alternatives — Are all non-text elements described?",
          "A score of 100% means the document passes all checks. If the score is lower, you can use the \"Fix with AI\" button on individual issues to improve it.",
        ],
      },
      {
        question: "What does 'Review' status mean?",
        answer: "If your document's compliance score is below 100%, it's marked as 'Review' to let you know there may be issues worth looking at. You can click on individual issues in the compliance report to see details, and use the AI fix button to address them.",
      },
      {
        question: "What does 'Accepted Limitation' mean?",
        answer: "Some accessibility issues can't be fully fixed by AI — for example, a decorative image that doesn't need a description, or a complex layout that the AI can't restructure. You can mark these as 'Accepted Limitation' to acknowledge the issue and exclude it from the compliance score.",
      },
    ],
  },
  {
    title: "Using Your Accessible File",
    items: [
      {
        question: "How do I upload the HTML file to Blackboard?",
        answer: [
          "There are two methods to add your accessible content to Blackboard:",
          "",
          "Method 1: Upload Word Document (Recommended)",
          "1. Click the green \"Download Word (.docx)\" button on the conversion page to save the file to your computer.",
          "2. Log in to Blackboard and open your course.",
          "3. In Course Content, click the + button.",
          "4. Click Upload and upload the .docx file — the same way you'd upload a syllabus or any other document.",
          "5. Click Save and make the file visible to students.",
          "",
          "Method 2: Paste HTML Inline (Alternative)",
          "1. Click the blue \"Copy HTML\" button on the conversion page to copy the accessible content to your clipboard.",
          "2. In Blackboard Ultra, go to Course Content and click the + button.",
          "3. Select \"Create\" and then \"Document\" to create a new content item.",
          "4. In \"Select a Type of Content to Add a Block\" click the \"HTML\" button (the </> icon) to switch to HTML view.",
          "5. Paste the copied HTML and click Save — no file download needed.",
          "6. Make the document visible to your students; they will see the accessible content inline.",
        ],
      },
      {
        question: "Can I share the file by email?",
        answer: "Yes. You can attach the Word (.docx) file or the HTML file to an email. The Word file opens in Microsoft Word or Google Docs, and the HTML file opens in any web browser — no special software is needed.",
      },
      {
        question: "Can I upload the file to Google Drive or OneDrive?",
        answer: "Yes. Upload the Word (.docx) or HTML file to Google Drive, OneDrive, or any cloud storage service. Word files can be previewed directly, and HTML files will open in the browser to display the accessible content.",
      },
      {
        question: "Will the accessible file work on phones and tablets?",
        answer: "Yes. Both the Word (.docx) and HTML files are designed to work on any device, including phones, tablets, and computers.",
      },
      {
        question: "What happened to the original PDF?",
        answer: "Your original PDF is not modified. The tool creates new accessible versions of your document (Word and HTML). You can keep using the original PDF alongside the accessible versions.",
      },
    ],
  },
  {
    title: "Fixing Issues",
    items: [
      {
        question: "How does 'Fix with AI' work?",
        answer: "When the compliance report shows an issue, you can click the \"Fix with AI\" button next to it. The AI will analyze the specific problem and update the HTML to fix it — for example, by adding a missing image description or correcting the heading structure. The compliance score updates automatically after the fix.",
      },
      {
        question: "Can the AI fix everything?",
        answer: "The AI can fix most common accessibility issues, like missing image descriptions, improper heading levels, and missing table headers. However, some complex issues may require manual review. If the AI can't fully fix something, you can mark it as an 'Accepted Limitation.'",
      },
      {
        question: "Will fixing one issue break something else?",
        answer: "No. The fix system is designed to target only the specific issue being fixed. Your other content and any previously fixed issues remain unchanged.",
      },
    ],
  },
  {
    title: "Privacy & Data",
    items: [
      {
        question: "Is my document data secure?",
        answer: "Yes. Your documents are processed securely and are only accessible to you through your authenticated account. Documents are not shared with other users.",
      },
      {
        question: "Can I delete my conversion history?",
        answer: "Your conversion history is tied to your account. If you need documents removed, please contact the BSU Teaching and Technology Center at TTC@bridgew.edu for assistance.",
      },
      {
        question: "Who can see my uploaded documents?",
        answer: "Only you can see your uploaded documents and conversion history. Each user's data is private and separated from other users' data.",
      },
    ],
  },
  {
    title: "Troubleshooting",
    items: [
      {
        question: "My PDF won't upload. What should I do?",
        answer: [
          "Try the following:",
          "• Make sure the file is a PDF (ends in .pdf).",
          "• Check that the file isn't too large. Try a smaller document first.",
          "• Make sure you're logged in.",
          "• Try refreshing the page and uploading again.",
          "If the problem persists, contact the BSU Teaching and Technology Center at TTC@bridgew.edu for help.",
        ],
      },
      {
        question: "The conversion seems stuck. What should I do?",
        answer: "Large or complex PDFs can take a few minutes to process. If it's been more than 5 minutes, try refreshing the page. Your conversion will continue processing in the background. Check the Conversion History page to see the current status.",
      },
      {
        question: "The converted document doesn't look right. What can I do?",
        answer: "The AI does its best to preserve the document's structure, but very complex layouts (like multi-column designs or embedded forms) may not convert perfectly. Review the compliance report for specific issues, and use the 'Fix with AI' button to address individual problems.",
      },
      {
        question: "Who do I contact for help?",
        answer: "For technical help or accessibility questions, contact the BSU Teaching and Technology Center at TTC@bridgew.edu.",
      },
    ],
  },
];

function FAQAccordionItem({ item }: { item: FAQItem }) {
  const [isOpen, setIsOpen] = useState(false);

  const answerContent = Array.isArray(item.answer)
    ? item.answer
    : [item.answer];

  return (
    <div className="border border-border rounded-xl overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center gap-3 p-4 text-left hover:bg-secondary/50 transition-colors duration-150"
        aria-expanded={isOpen}
      >
        {isOpen ? (
          <ChevronDown className="h-4 w-4 text-blue-600 dark:text-blue-400 flex-shrink-0" aria-hidden="true" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" aria-hidden="true" />
        )}
        <span className={cn("text-sm font-semibold", isOpen ? "text-blue-600 dark:text-blue-400" : "text-foreground")}>
          {item.question}
        </span>
      </button>
      {isOpen && (
        <div className="px-4 pb-4 pl-11">
          <div className="text-sm text-muted-foreground space-y-2">
            {answerContent.map((line, i) => (
              <p key={i} className={cn(i > 0 && line.startsWith("•") ? "ml-2" : "", i > 0 && /^\d+\./.test(line) ? "ml-2" : "")}>
                {line}
              </p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function FAQ() {
  return (
    <Layout>
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-serif font-bold text-foreground">
            Frequently Asked Questions
          </h1>
          <p className="text-muted-foreground mt-2">
            Everything you need to know about converting PDFs into accessible documents.
          </p>
        </div>

        <div className="space-y-8">
          {FAQ_SECTIONS.map((section) => (
            <section key={section.title} aria-labelledby={`faq-section-${section.title.toLowerCase().replace(/\s+/g, "-")}`}>
              <h2
                id={`faq-section-${section.title.toLowerCase().replace(/\s+/g, "-")}`}
                className="text-lg font-bold text-foreground mb-3"
              >
                {section.title}
              </h2>
              <div className="space-y-2">
                {section.items.map((item) => (
                  <FAQAccordionItem key={item.question} item={item} />
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="mt-10 p-6 bg-secondary/50 border border-border rounded-2xl text-center">
          <h2 className="font-bold text-foreground mb-2">Still have questions?</h2>
          <p className="text-sm text-muted-foreground">
            Contact the <strong className="text-foreground/80">BSU Teaching and Technology Center</strong> for technical help or accessibility guidance at{" "}
            <a href="mailto:TTC@bridgew.edu" className="underline text-primary hover:text-primary/80 font-medium">TTC@bridgew.edu</a>.
          </p>
        </div>
      </div>
    </Layout>
  );
}
