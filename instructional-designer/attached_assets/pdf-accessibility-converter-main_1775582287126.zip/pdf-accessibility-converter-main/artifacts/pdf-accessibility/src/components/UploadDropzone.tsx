import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { motion, AnimatePresence } from "framer-motion";
import { UploadCloud, File, AlertCircle, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface UploadDropzoneProps {
  onUpload: (file: File) => void;
  isUploading: boolean;
}

export function UploadDropzone({ onUpload, isUploading }: UploadDropzoneProps) {
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: { file: File; errors: { code: string; message: string }[] }[]) => {
    setError(null);
    if (rejectedFiles.length > 0) {
      setError("Please upload a valid PDF document under 20MB.");
      return;
    }
    if (acceptedFiles.length > 0) {
      onUpload(acceptedFiles[0]);
    }
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    maxFiles: 1,
    maxSize: 20 * 1024 * 1024,
    disabled: isUploading
  });

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div 
        {...getRootProps()} 
        className={cn(
          "relative overflow-hidden group border-3 border-dashed rounded-3xl p-12 text-center transition-all duration-300 ease-out outline-none focus-visible:ring-4 focus-visible:ring-primary/20",
          isDragActive 
            ? "border-primary bg-primary/5 scale-[1.02]" 
            : "border-border hover:border-primary/50 hover:bg-secondary/50 bg-card",
          isUploading && "opacity-50 cursor-not-allowed pointer-events-none"
        )}
      >
        <input {...getInputProps()} aria-label="PDF File Upload" />
        
        <div className="flex flex-col items-center justify-center space-y-6">
          <div className={cn(
            "p-5 rounded-2xl transition-colors duration-300",
            isUploading
              ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
              : isDragActive
                ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                : "bg-secondary text-primary group-hover:bg-primary group-hover:text-primary-foreground"
          )}>
            {isUploading ? (
              <Loader2 className="w-10 h-10 animate-spin" aria-hidden="true" />
            ) : (
              <UploadCloud className="w-10 h-10" aria-hidden="true" />
            )}
          </div>
          
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-foreground">
              {isUploading
                ? "Uploading & processing..."
                : isDragActive
                  ? "Drop PDF here"
                  : "Select a PDF to remediate"}
            </h2>
            <p className="text-muted-foreground font-medium max-w-sm mx-auto">
              {isUploading
                ? "Your document is being uploaded and prepared for accessibility remediation."
                : "Drag and drop your document here, or click to browse. We will automatically generate an accessible WCAG 2.1 AA compliant version."}
            </p>
          </div>
          
          {!isUploading && (
            <div className="flex items-center gap-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              <span className="flex items-center gap-2 bg-background px-4 py-2 rounded-full border shadow-sm">
                <File className="w-4 h-4" aria-hidden="true" />
                PDF up to 20MB
              </span>
              <span className="bg-background px-4 py-2 rounded-full border shadow-sm">
                One document at a time
              </span>
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 p-4 bg-destructive/10 border border-destructive/20 text-destructive rounded-xl flex items-center gap-3 shadow-sm"
            role="alert"
            aria-live="assertive"
          >
            <AlertCircle className="w-5 h-5 flex-shrink-0" aria-hidden="true" />
            <p className="font-medium text-sm">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
