import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from "recharts";
import { type ComplianceReport } from "@workspace/api-client-react";

interface ComplianceChartProps {
  report: ComplianceReport;
}

export function ComplianceChart({ report }: ComplianceChartProps) {
  const data = [
    { name: 'Passed', value: report.passCount, color: 'hsl(142 71% 25%)' },
    { name: 'Fixed (AI)', value: report.fixedCount, color: 'hsl(348 83% 40%)' },
    { name: 'Accepted', value: report.acceptedCount ?? 0, color: 'hsl(263 70% 50%)' },
    { name: 'Warning', value: report.warningCount, color: 'hsl(35 92% 33%)' },
    { name: 'Failed', value: report.failCount, color: 'hsl(354 84% 35%)' },
  ].filter(item => item.value > 0);

  if (data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-muted-foreground">No data available</div>;
  }

  const summary = data.map(d => `${d.name}: ${d.value}`).join(', ');

  return (
    <div 
      className="h-64 w-full" 
      role="img" 
      aria-label={`Compliance chart: ${summary}. ${report.totalIssues} total issues.`}
    >
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
            stroke="none"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <RechartsTooltip 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
            itemStyle={{ fontWeight: 'bold' }}
          />
          <Legend verticalAlign="bottom" height={36} iconType="circle" />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
