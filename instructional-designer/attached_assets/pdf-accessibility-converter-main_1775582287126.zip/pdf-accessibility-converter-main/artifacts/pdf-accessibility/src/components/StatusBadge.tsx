import { cn } from "@/lib/utils";
import { CheckCircle2, Clock, AlertCircle, XCircle, Loader2, ShieldAlert } from "lucide-react";

type StatusType = "uploaded" | "processing" | "completed" | "failed" | "review" | "pass" | "fail" | "fixed" | "warning" | "accepted";

interface StatusBadgeProps {
  status: StatusType;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const variants = {
    uploaded: "bg-secondary text-secondary-foreground border-secondary-foreground/20",
    processing: "bg-info/10 text-info border-info/20",
    completed: "bg-success/10 text-success border-success/20",
    review: "bg-warning/10 text-warning border-warning/20",
    pass: "bg-success/10 text-success border-success/20",
    fixed: "bg-success/10 text-success border-success/20",
    warning: "bg-warning/10 text-warning border-warning/20",
    failed: "bg-destructive/10 text-destructive border-destructive/20",
    fail: "bg-destructive/10 text-destructive border-destructive/20",
    accepted: "bg-violet-500/10 text-violet-600 border-violet-500/20 dark:text-violet-400",
  };

  const icons = {
    uploaded: <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />,
    processing: <Clock className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />,
    completed: <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />,
    review: <AlertCircle className="w-3.5 h-3.5" aria-hidden="true" />,
    pass: <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />,
    fixed: <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />,
    warning: <AlertCircle className="w-3.5 h-3.5" aria-hidden="true" />,
    failed: <XCircle className="w-3.5 h-3.5" aria-hidden="true" />,
    fail: <XCircle className="w-3.5 h-3.5" aria-hidden="true" />,
    accepted: <ShieldAlert className="w-3.5 h-3.5" aria-hidden="true" />,
  };

  const labels = {
    uploaded: "Starting...",
    processing: "Remediating...",
    completed: "Accessible",
    review: "Review",
    failed: "Failed",
    pass: "Pass",
    fail: "Fail",
    fixed: "Fixed via AI",
    warning: "Manual Review",
    accepted: "Accepted Limitation",
  };

  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border",
      variants[status],
      className
    )}>
      {icons[status]}
      {labels[status]}
    </span>
  );
}
