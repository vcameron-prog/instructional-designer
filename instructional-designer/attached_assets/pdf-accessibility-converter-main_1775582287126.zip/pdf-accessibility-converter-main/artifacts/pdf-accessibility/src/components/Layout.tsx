import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { FileText, History, HelpCircle, LogIn, LogOut, User, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@workspace/replit-auth-web";
import { useAdminCheck } from "@/hooks/use-admin";
import { AccessibilitySettings } from "./AccessibilitySettings";

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { user, isLoading, isAuthenticated, login, logout } = useAuth();
  const { data: adminCheck } = useAdminCheck();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <svg className="absolute w-0 h-0" aria-hidden="true">
        <defs>
          <filter id="cb-protanopia">
            <feColorMatrix type="matrix" values="0.567, 0.433, 0, 0, 0  0.558, 0.442, 0, 0, 0  0, 0.242, 0.758, 0, 0  0, 0, 0, 1, 0" />
          </filter>
          <filter id="cb-deuteranopia">
            <feColorMatrix type="matrix" values="0.625, 0.375, 0, 0, 0  0.7, 0.3, 0, 0, 0  0, 0.3, 0.7, 0, 0  0, 0, 0, 1, 0" />
          </filter>
          <filter id="cb-tritanopia">
            <feColorMatrix type="matrix" values="0.95, 0.05, 0, 0, 0  0, 0.433, 0.567, 0, 0  0, 0.475, 0.525, 0, 0  0, 0, 0, 1, 0" />
          </filter>
          <filter id="cb-achromatopsia">
            <feColorMatrix type="matrix" values="0.299, 0.587, 0.114, 0, 0  0.299, 0.587, 0.114, 0, 0  0.299, 0.587, 0.114, 0, 0  0, 0, 0, 1, 0" />
          </filter>
        </defs>
      </svg>
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>

      <header className="sticky top-0 z-40 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 shadow-sm" role="banner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-20 items-center justify-between">
            <Link href="/" className="flex items-center gap-3 no-underline">
              <div className="bg-primary p-2.5 rounded-xl text-primary-foreground shadow-md shadow-primary/20">
                <FileText className="h-6 w-6" aria-hidden="true" />
              </div>
              <div>
                <span className="text-xl font-serif font-bold text-foreground leading-tight block">
                  BSU PDF
                </span>
                <span className="text-xs text-muted-foreground font-sans font-medium uppercase tracking-wider block">
                  Title II Remediation
                </span>
              </div>
            </Link>

            <div className="flex items-center gap-2 sm:gap-4">
              <nav className="flex items-center space-x-1 sm:space-x-4" aria-label="Main Navigation">
                <Link 
                  href="/history" 
                  aria-current={location.startsWith("/history") || location.startsWith("/conversion") ? "page" : undefined}
                  aria-label="Conversion History"
                  className={cn(
                    "flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200",
                    location.startsWith("/history") || location.startsWith("/conversion")
                      ? "bg-primary/10 text-primary" 
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <History className={cn("h-4 w-4", (location.startsWith("/history") || location.startsWith("/conversion")) && "text-violet-600 dark:text-violet-400")} aria-hidden="true" />
                  <span className="hidden sm:inline">Conversion History</span>
                </Link>
                <Link
                  href="/faq"
                  aria-current={location === "/faq" ? "page" : undefined}
                  aria-label="FAQ"
                  className={cn(
                    "flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200",
                    location === "/faq"
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <HelpCircle className={cn("h-4 w-4", location === "/faq" && "text-blue-600 dark:text-blue-400")} aria-hidden="true" />
                  <span className="hidden sm:inline">FAQ</span>
                </Link>
                {adminCheck?.isAdmin && (
                  <Link
                    href="/admin"
                    aria-current={location === "/admin" ? "page" : undefined}
                    aria-label="Admin Dashboard"
                    className={cn(
                      "flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200",
                      location === "/admin"
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                    )}
                  >
                    <ShieldCheck className={cn("h-4 w-4", location === "/admin" && "text-emerald-600 dark:text-emerald-400")} aria-hidden="true" />
                    <span className="hidden sm:inline">Admin</span>
                  </Link>
                )}
              </nav>

              <AccessibilitySettings />

              <div className="border-l border-border pl-2 sm:pl-4">
                {isLoading ? (
                  <div className="w-8 h-8 rounded-full bg-secondary animate-pulse" role="status" aria-label="Loading user info" />
                ) : isAuthenticated && user ? (
                  <div className="flex items-center gap-2 sm:gap-3">
                    {user.profileImageUrl ? (
                      <img 
                        src={user.profileImageUrl} 
                        alt={`Profile photo of ${user.firstName || user.email || "User"}`}
                        className="w-8 h-8 rounded-full object-cover border-2 border-primary/20"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center" aria-hidden="true">
                        <User className="w-4 h-4" aria-hidden="true" />
                      </div>
                    )}
                    <span className="hidden md:inline text-sm font-semibold text-foreground truncate max-w-[120px]">
                      {user.firstName || user.email || "User"}
                    </span>
                    <button
                      onClick={logout}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground transition-all duration-200"
                      aria-label="Log out"
                    >
                      <LogOut className="h-4 w-4" aria-hidden="true" />
                      <span className="hidden sm:inline">Log out</span>
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={login}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold bg-primary text-primary-foreground shadow-md shadow-primary/20 hover:-translate-y-0.5 transition-all duration-200"
                    aria-label="Log in"
                  >
                    <LogIn className="h-4 w-4" aria-hidden="true" />
                    <span className="hidden sm:inline">Log in</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main id="main-content" className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12" role="main">
        {children}
      </main>
      
      <footer className="border-t bg-card py-8 mt-auto" role="contentinfo">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-muted-foreground">
          <p>Bridgewater State University PDF Title II Remediation. Compliant with WCAG 2.1 Level AA.</p>
          <p>Brought to you by the BSU Teaching and Technology Center & Center for AI</p>
        </div>
      </footer>
    </div>
  );
}
