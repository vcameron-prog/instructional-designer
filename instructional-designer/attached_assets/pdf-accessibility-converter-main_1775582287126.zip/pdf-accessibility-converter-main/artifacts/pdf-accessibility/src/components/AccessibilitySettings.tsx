import { useState, useEffect, useCallback } from "react";
import { useTheme } from "next-themes";
import { useLocation } from "wouter";
import { Settings, Sun, Moon, Monitor, Eye } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

type FontSize = "small" | "medium" | "large" | "extra-large";
type ColorBlindMode = "none" | "protanopia" | "deuteranopia" | "tritanopia" | "achromatopsia";

const FONT_SIZE_MAP: Record<FontSize, string> = {
  small: "87.5%",
  medium: "100%",
  large: "112.5%",
  "extra-large": "125%",
};

const FONT_SIZE_LABELS: Record<FontSize, string> = {
  small: "Small",
  medium: "Medium",
  large: "Large",
  "extra-large": "Extra Large",
};

const COLOR_BLIND_LABELS: Record<ColorBlindMode, string> = {
  none: "None",
  protanopia: "Protanopia (red-blind)",
  deuteranopia: "Deuteranopia (green-blind)",
  tritanopia: "Tritanopia (blue-blind)",
  achromatopsia: "Achromatopsia (no color)",
};

const VALID_FONT_SIZES: FontSize[] = ["small", "medium", "large", "extra-large"];
const VALID_CB_MODES: ColorBlindMode[] = ["none", "protanopia", "deuteranopia", "tritanopia", "achromatopsia"];

function getStoredValue<T extends string>(key: string, fallback: T, allowed: readonly T[]): T {
  try {
    const val = localStorage.getItem(key);
    if (val && (allowed as readonly string[]).includes(val)) {
      return val as T;
    }
    return fallback;
  } catch {
    return fallback;
  }
}

function applyFontSize(size: FontSize) {
  document.documentElement.style.fontSize = FONT_SIZE_MAP[size];
}

function applyColorBlindMode(mode: ColorBlindMode) {
  document.documentElement.removeAttribute("data-cb-mode");
  document.body.removeAttribute("data-cb-mode");
  if (mode !== "none") {
    const absoluteUrl = `${window.location.origin}${window.location.pathname}#cb-${mode}`;
    document.body.style.filter = `url("${absoluteUrl}")`;
  } else {
    document.body.style.filter = "";
  }
}

export function AccessibilitySettings() {
  const { theme, setTheme } = useTheme();
  const [fontSize, setFontSize] = useState<FontSize>(() => getStoredValue("a11y-font-size", "medium", VALID_FONT_SIZES));
  const [colorBlindMode, setColorBlindMode] = useState<ColorBlindMode>(() => getStoredValue("a11y-cb-mode", "none", VALID_CB_MODES));
  const [location] = useLocation();

  useEffect(() => {
    applyFontSize(fontSize);
    localStorage.setItem("a11y-font-size", fontSize);
  }, [fontSize]);

  useEffect(() => {
    applyColorBlindMode(colorBlindMode);
    localStorage.setItem("a11y-cb-mode", colorBlindMode);
  }, [colorBlindMode, location]);

  const handleThemeChange = useCallback((value: string) => setTheme(value), [setTheme]);
  const handleFontSizeChange = useCallback((value: string) => setFontSize(value as FontSize), []);
  const handleColorBlindChange = useCallback((value: string) => setColorBlindMode(value as ColorBlindMode), []);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          className="flex items-center justify-center w-9 h-9 rounded-xl text-muted-foreground hover:bg-secondary hover:text-foreground transition-all duration-200"
          aria-label="Accessibility settings"
        >
          <Settings className="h-5 w-5" aria-hidden="true" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-80 p-0 bg-card border-border"
        align="end"
        sideOffset={8}
      >
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Eye className="h-4 w-4 text-blue-600 dark:text-blue-400" aria-hidden="true" />
            <h2 className="text-sm font-semibold text-foreground">Accessibility Settings</h2>
          </div>
        </div>

        <div className="p-4 space-y-5 max-h-[70vh] overflow-y-auto">
          <fieldset>
            <legend className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Theme</legend>
            <RadioGroup value={theme || "system"} onValueChange={handleThemeChange} className="grid grid-cols-3 gap-2">
              {([
                { value: "light", label: "Light", icon: Sun },
                { value: "dark", label: "Dark", icon: Moon },
                { value: "system", label: "System", icon: Monitor },
              ] as const).map(({ value, label, icon: Icon }) => (
                <Label
                  key={value}
                  htmlFor={`theme-${value}`}
                  className={cn(
                    "flex flex-col items-center gap-1.5 p-2.5 rounded-lg border cursor-pointer transition-all duration-150",
                    (theme || "system") === value
                      ? "border-primary bg-primary/5 text-primary"
                      : "border-border text-muted-foreground hover:border-primary/30 hover:bg-secondary"
                  )}
                >
                  <RadioGroupItem value={value} id={`theme-${value}`} className="sr-only" />
                  <Icon className="h-4 w-4" aria-hidden="true" />
                  <span className="text-xs font-medium">{label}</span>
                </Label>
              ))}
            </RadioGroup>
          </fieldset>

          <fieldset>
            <legend className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Font Size</legend>
            <RadioGroup value={fontSize} onValueChange={handleFontSizeChange} className="grid grid-cols-2 gap-2">
              {(Object.entries(FONT_SIZE_LABELS) as [FontSize, string][]).map(([value, label]) => (
                <Label
                  key={value}
                  htmlFor={`font-${value}`}
                  className={cn(
                    "flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-all duration-150",
                    fontSize === value
                      ? "border-primary bg-primary/5 text-primary"
                      : "border-border text-muted-foreground hover:border-primary/30 hover:bg-secondary"
                  )}
                >
                  <RadioGroupItem value={value} id={`font-${value}`} className="sr-only" />
                  <span className="text-xs font-medium">{label}</span>
                </Label>
              ))}
            </RadioGroup>
          </fieldset>

          <fieldset>
            <legend className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Color Blindness Mode</legend>
            <RadioGroup value={colorBlindMode} onValueChange={handleColorBlindChange} className="space-y-1.5">
              {(Object.entries(COLOR_BLIND_LABELS) as [ColorBlindMode, string][]).map(([value, label]) => (
                <Label
                  key={value}
                  htmlFor={`cbr-${value}`}
                  className={cn(
                    "flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-all duration-150",
                    colorBlindMode === value
                      ? "border-primary bg-primary/5 text-primary"
                      : "border-border text-muted-foreground hover:border-primary/30 hover:bg-secondary"
                  )}
                >
                  <RadioGroupItem value={value} id={`cbr-${value}`} className="sr-only" />
                  <span className="text-xs font-medium">{label}</span>
                </Label>
              ))}
            </RadioGroup>
          </fieldset>
        </div>
      </PopoverContent>
    </Popover>
  );
}
