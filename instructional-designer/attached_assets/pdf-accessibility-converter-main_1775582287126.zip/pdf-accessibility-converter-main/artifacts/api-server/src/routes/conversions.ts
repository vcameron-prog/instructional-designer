import { Router, type IRouter } from "express";
import multer from "multer";
import { eq, desc, and } from "drizzle-orm";
import { db, conversionsTable } from "@workspace/db";
import {
  GetConversionParams,
  DeleteConversionParams,
  ProcessConversionParams,
  DownloadAccessibleHtmlParams,
  FixComplianceIssueBody,
  AcceptComplianceIssueBody,
  RevertComplianceIssueBody,
  UpdateConversionHtmlBody,
} from "@workspace/api-zod";
import { extractPdfContent, needsOcr, findScannedPages } from "../lib/pdf-processor";
import { generateAccessibleDocument, fixComplianceIssue, buildComplianceReport, complianceReportSchema, evaluateOriginalDocument, performOcr } from "../lib/accessibility-engine";

const router: IRouter = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed"));
    }
  },
});

router.get("/conversions", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const rows = await db
    .select({
      id: conversionsTable.id,
      originalFilename: conversionsTable.originalFilename,
      fileSize: conversionsTable.fileSize,
      status: conversionsTable.status,
      pageCount: conversionsTable.pageCount,
      complianceReport: conversionsTable.complianceReport,
      createdAt: conversionsTable.createdAt,
      updatedAt: conversionsTable.updatedAt,
    })
    .from(conversionsTable)
    .where(eq(conversionsTable.userId, req.user.id))
    .orderBy(desc(conversionsTable.createdAt));

  const conversions = rows.map((row) => {
    const report = row.complianceReport as { overallScore?: number } | null;
    return {
      id: row.id,
      originalFilename: row.originalFilename,
      fileSize: row.fileSize,
      status: row.status,
      pageCount: row.pageCount,
      complianceScore: report?.overallScore ?? null,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  });

  res.json(conversions);
});

router.post("/conversions", upload.single("file"), async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  if (!req.file) {
    res.status(400).json({ error: "No PDF file uploaded" });
    return;
  }

  const pdfBuffer = req.file.buffer;
  let pageCount: number | null = null;
  let extractedText: string | null = null;

  try {
    const extraction = await extractPdfContent(pdfBuffer);
    pageCount = extraction.pageCount;
    extractedText = extraction.text;
  } catch {
  }

  const [conversion] = await db
    .insert(conversionsTable)
    .values({
      originalFilename: req.file.originalname,
      fileSize: req.file.size,
      status: "uploaded",
      pageCount,
      extractedText,
      pdfData: pdfBuffer.toString("base64"),
      userId: req.user.id,
    })
    .returning();

  res.status(201).json({
    id: conversion.id,
    originalFilename: conversion.originalFilename,
    fileSize: conversion.fileSize,
    status: conversion.status,
    pageCount: conversion.pageCount,
    complianceScore: null,
    createdAt: conversion.createdAt,
    updatedAt: conversion.updatedAt,
  });
});

router.get("/conversions/:id", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = GetConversionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [conversion] = await db
    .select({
      id: conversionsTable.id,
      originalFilename: conversionsTable.originalFilename,
      fileSize: conversionsTable.fileSize,
      status: conversionsTable.status,
      pageCount: conversionsTable.pageCount,
      extractedText: conversionsTable.extractedText,
      accessibleHtml: conversionsTable.accessibleHtml,
      complianceReport: conversionsTable.complianceReport,
      originalComplianceReport: conversionsTable.originalComplianceReport,
      errorMessage: conversionsTable.errorMessage,
      ocrApplied: conversionsTable.ocrApplied,
      createdAt: conversionsTable.createdAt,
      updatedAt: conversionsTable.updatedAt,
    })
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!conversion) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  res.json(conversion);
});

router.delete("/conversions/:id", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = DeleteConversionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [existing] = await db
    .select({ id: conversionsTable.id })
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!existing) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  await db
    .delete(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  res.sendStatus(204);
});

router.post("/conversions/:id/process", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = ProcessConversionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [conversion] = await db
    .select()
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!conversion) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  await db
    .update(conversionsTable)
    .set({ status: "processing" })
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  try {
    let images: import("../lib/pdf-processor").ExtractedImage[] = [];
    let tables: import("../lib/pdf-processor").ExtractedTable[] = [];
    let metadata: { title?: string; author?: string; subject?: string } = {
      title: conversion.originalFilename.replace(/\.pdf$/i, ""),
    };

    if (conversion.pdfData) {
      try {
        const pdfBuffer = Buffer.from(conversion.pdfData, "base64");
        const fullExtraction = await extractPdfContent(pdfBuffer);
        images = fullExtraction.images;
        tables = fullExtraction.tables;
        if (fullExtraction.metadata.title) {
          metadata.title = fullExtraction.metadata.title;
        }
        if (fullExtraction.metadata.author) {
          metadata.author = fullExtraction.metadata.author;
        }
        if (fullExtraction.metadata.subject) {
          metadata.subject = fullExtraction.metadata.subject;
        }
      } catch {
      }
    }

    let textForRemediation = conversion.extractedText || "";
    let ocrApplied = false;
    const pageCount = conversion.pageCount || 1;

    const scannedPages = findScannedPages(images);
    const overallLowText = needsOcr(textForRemediation, pageCount);

    if (overallLowText || scannedPages.size > 0) {
      const pagesToOcr = scannedPages.size > 0 ? scannedPages : undefined;
      const ocrText = await performOcr(images, pageCount, pagesToOcr);
      if (ocrText) {
        const ocrChars = ocrText.replace(/\s+/g, " ").replace(/---\s*Page\s+\d+\s*---/g, "").trim().length;
        const ocrCharsPerPage = pagesToOcr ? ocrChars / pagesToOcr.size : ocrChars / pageCount;
        if (ocrCharsPerPage < 20 && !textForRemediation.trim()) {
          throw new Error(
            "OCR produced very little readable text from this scanned PDF. The scan quality may be too low. Please try uploading a higher-quality scan."
          );
        }
        if (textForRemediation.trim()) {
          textForRemediation = textForRemediation + "\n\n--- OCR Extracted Text ---\n\n" + ocrText;
        } else {
          textForRemediation = ocrText;
        }
        ocrApplied = true;
      }
    }

    if (!textForRemediation.trim()) {
      throw new Error("No text could be extracted from this PDF. If this is a scanned document, the scan quality may be too low.");
    }

    const originalReport = evaluateOriginalDocument(textForRemediation);

    const result = await generateAccessibleDocument(
      textForRemediation,
      conversion.originalFilename,
      metadata,
      images,
      tables,
    );

    const [updated] = await db
      .update(conversionsTable)
      .set({
        status: "completed",
        accessibleHtml: result.accessibleHtml,
        complianceReport: result.complianceReport,
        originalComplianceReport: originalReport,
        ocrApplied,
      })
      .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)))
      .returning({
        id: conversionsTable.id,
        originalFilename: conversionsTable.originalFilename,
        fileSize: conversionsTable.fileSize,
        status: conversionsTable.status,
        pageCount: conversionsTable.pageCount,
        extractedText: conversionsTable.extractedText,
        accessibleHtml: conversionsTable.accessibleHtml,
        complianceReport: conversionsTable.complianceReport,
        originalComplianceReport: conversionsTable.originalComplianceReport,
        errorMessage: conversionsTable.errorMessage,
        ocrApplied: conversionsTable.ocrApplied,
        createdAt: conversionsTable.createdAt,
        updatedAt: conversionsTable.updatedAt,
      });

    res.json(updated);
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : "Processing failed";
    await db
      .update(conversionsTable)
      .set({ status: "failed", errorMessage })
      .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

    const [failed] = await db
      .select({
        id: conversionsTable.id,
        originalFilename: conversionsTable.originalFilename,
        fileSize: conversionsTable.fileSize,
        status: conversionsTable.status,
        pageCount: conversionsTable.pageCount,
        extractedText: conversionsTable.extractedText,
        accessibleHtml: conversionsTable.accessibleHtml,
        complianceReport: conversionsTable.complianceReport,
        originalComplianceReport: conversionsTable.originalComplianceReport,
        errorMessage: conversionsTable.errorMessage,
        ocrApplied: conversionsTable.ocrApplied,
        createdAt: conversionsTable.createdAt,
        updatedAt: conversionsTable.updatedAt,
      })
      .from(conversionsTable)
      .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

    res.json(failed);
  }
});

router.post("/conversions/:id/fix-issue", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = GetConversionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = FixComplianceIssueBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const { issueIndex } = body.data;

  const [conversion] = await db
    .select({
      id: conversionsTable.id,
      accessibleHtml: conversionsTable.accessibleHtml,
      complianceReport: conversionsTable.complianceReport,
      status: conversionsTable.status,
    })
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!conversion) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  if (conversion.status !== "completed" || !conversion.accessibleHtml || !conversion.complianceReport) {
    res.status(400).json({ error: "Conversion must be completed before fixing issues" });
    return;
  }

  const reportResult = complianceReportSchema.safeParse(conversion.complianceReport);
  if (!reportResult.success) {
    res.status(500).json({ error: "Stored compliance report is malformed" });
    return;
  }
  const report = reportResult.data;
  if (issueIndex >= report.issues.length) {
    res.status(400).json({ error: "Issue index out of range" });
    return;
  }

  const issue = report.issues[issueIndex];
  if (!issue) {
    res.status(400).json({ error: "Issue index out of range" });
    return;
  }
  if (issue.status !== "fail" && issue.status !== "warning") {
    res.status(400).json({ error: "Only failed or warning issues can be fixed" });
    return;
  }

  try {
    const result = await fixComplianceIssue(
      conversion.accessibleHtml,
      issue,
      issueIndex,
      report
    );

    const [updated] = await db
      .update(conversionsTable)
      .set({
        accessibleHtml: result.accessibleHtml,
        complianceReport: result.complianceReport,
      })
      .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)))
      .returning({
        id: conversionsTable.id,
        originalFilename: conversionsTable.originalFilename,
        fileSize: conversionsTable.fileSize,
        status: conversionsTable.status,
        pageCount: conversionsTable.pageCount,
        extractedText: conversionsTable.extractedText,
        accessibleHtml: conversionsTable.accessibleHtml,
        complianceReport: conversionsTable.complianceReport,
        originalComplianceReport: conversionsTable.originalComplianceReport,
        errorMessage: conversionsTable.errorMessage,
        ocrApplied: conversionsTable.ocrApplied,
        createdAt: conversionsTable.createdAt,
        updatedAt: conversionsTable.updatedAt,
      });

    res.json(updated);
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : "Fix failed";
    res.status(500).json({ error: errorMessage });
  }
});

router.post("/conversions/:id/accept-issue", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = GetConversionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = AcceptComplianceIssueBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const { issueIndex, justification } = body.data;

  const trimmedJustification = justification.trim();
  if (!trimmedJustification) {
    res.status(400).json({ error: "Justification cannot be empty" });
    return;
  }

  const [conversion] = await db
    .select({
      id: conversionsTable.id,
      complianceReport: conversionsTable.complianceReport,
      status: conversionsTable.status,
    })
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!conversion) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  if (conversion.status !== "completed" || !conversion.complianceReport) {
    res.status(400).json({ error: "Conversion must be completed before accepting issues" });
    return;
  }

  const reportResult = complianceReportSchema.safeParse(conversion.complianceReport);
  if (!reportResult.success) {
    res.status(500).json({ error: "Stored compliance report is malformed" });
    return;
  }
  const report = reportResult.data;
  if (issueIndex >= report.issues.length) {
    res.status(400).json({ error: "Issue index out of range" });
    return;
  }

  const issue = report.issues[issueIndex];
  if (!issue) {
    res.status(400).json({ error: "Issue index out of range" });
    return;
  }
  if (issue.status !== "fail" && issue.status !== "warning") {
    res.status(400).json({ error: "Only failed or warning issues can be accepted" });
    return;
  }

  issue.previousStatus = issue.status as "fail" | "warning";
  issue.status = "accepted";
  issue.justification = trimmedJustification;
  const updatedReport = buildComplianceReport(report.issues);

  const [updated] = await db
    .update(conversionsTable)
    .set({
      complianceReport: updatedReport,
    })
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)))
    .returning({
      id: conversionsTable.id,
      originalFilename: conversionsTable.originalFilename,
      fileSize: conversionsTable.fileSize,
      status: conversionsTable.status,
      pageCount: conversionsTable.pageCount,
      extractedText: conversionsTable.extractedText,
      accessibleHtml: conversionsTable.accessibleHtml,
      complianceReport: conversionsTable.complianceReport,
      originalComplianceReport: conversionsTable.originalComplianceReport,
      errorMessage: conversionsTable.errorMessage,
      ocrApplied: conversionsTable.ocrApplied,
      createdAt: conversionsTable.createdAt,
      updatedAt: conversionsTable.updatedAt,
    });

  res.json(updated);
});

router.post("/conversions/:id/revert-issue", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = GetConversionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = RevertComplianceIssueBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const { issueIndex } = body.data;

  const [conversion] = await db
    .select({
      id: conversionsTable.id,
      complianceReport: conversionsTable.complianceReport,
      status: conversionsTable.status,
    })
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!conversion) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  if (conversion.status !== "completed" || !conversion.complianceReport) {
    res.status(400).json({ error: "Conversion must be completed before reverting issues" });
    return;
  }

  const reportResult = complianceReportSchema.safeParse(conversion.complianceReport);
  if (!reportResult.success) {
    res.status(500).json({ error: "Stored compliance report is malformed" });
    return;
  }
  const report = reportResult.data;
  if (issueIndex >= report.issues.length) {
    res.status(400).json({ error: "Issue index out of range" });
    return;
  }

  const issue = report.issues[issueIndex];
  if (!issue) {
    res.status(400).json({ error: "Issue index out of range" });
    return;
  }
  if (issue.status !== "accepted") {
    res.status(400).json({ error: "Only accepted issues can be reverted" });
    return;
  }

  issue.status = issue.previousStatus === "warning" ? "warning" : "fail";
  delete issue.justification;
  delete issue.previousStatus;
  const updatedReport = buildComplianceReport(report.issues);

  const [updated] = await db
    .update(conversionsTable)
    .set({
      complianceReport: updatedReport,
    })
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)))
    .returning({
      id: conversionsTable.id,
      originalFilename: conversionsTable.originalFilename,
      fileSize: conversionsTable.fileSize,
      status: conversionsTable.status,
      pageCount: conversionsTable.pageCount,
      extractedText: conversionsTable.extractedText,
      accessibleHtml: conversionsTable.accessibleHtml,
      complianceReport: conversionsTable.complianceReport,
      originalComplianceReport: conversionsTable.originalComplianceReport,
      errorMessage: conversionsTable.errorMessage,
      ocrApplied: conversionsTable.ocrApplied,
      createdAt: conversionsTable.createdAt,
      updatedAt: conversionsTable.updatedAt,
    });

  res.json(updated);
});

router.put("/conversions/:id/html", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = GetConversionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = UpdateConversionHtmlBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [conversion] = await db
    .select({ id: conversionsTable.id, status: conversionsTable.status })
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!conversion) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  if (conversion.status !== "completed") {
    res.status(400).json({ error: "Conversion must be completed before editing HTML" });
    return;
  }

  const [updated] = await db
    .update(conversionsTable)
    .set({
      accessibleHtml: body.data.html,
    })
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)))
    .returning({
      id: conversionsTable.id,
      originalFilename: conversionsTable.originalFilename,
      fileSize: conversionsTable.fileSize,
      status: conversionsTable.status,
      pageCount: conversionsTable.pageCount,
      extractedText: conversionsTable.extractedText,
      accessibleHtml: conversionsTable.accessibleHtml,
      complianceReport: conversionsTable.complianceReport,
      originalComplianceReport: conversionsTable.originalComplianceReport,
      errorMessage: conversionsTable.errorMessage,
      ocrApplied: conversionsTable.ocrApplied,
      createdAt: conversionsTable.createdAt,
      updatedAt: conversionsTable.updatedAt,
    });

  res.json(updated);
});

router.get("/conversions/:id/download", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = DownloadAccessibleHtmlParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [conversion] = await db
    .select({
      accessibleHtml: conversionsTable.accessibleHtml,
      originalFilename: conversionsTable.originalFilename,
      status: conversionsTable.status,
      updatedAt: conversionsTable.updatedAt,
    })
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!conversion) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  if (conversion.status !== "completed" || !conversion.accessibleHtml) {
    res.status(400).json({ error: "Accessible HTML is not yet available" });
    return;
  }

  let html = conversion.accessibleHtml;
  const updatedDate = conversion.updatedAt ? new Date(conversion.updatedAt) : new Date();
  const isoDate = updatedDate.toISOString();
  const readableDate = updatedDate.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  const metaTag = `<meta name="date" content="${isoDate}">`;
  const headCloseIdx = html.indexOf("</head>");
  if (headCloseIdx !== -1) {
    html = html.slice(0, headCloseIdx) + `  ${metaTag}\n` + html.slice(headCloseIdx);
  }

  const timestampFooter = `\n<footer style="margin-top:2rem;padding:1rem 0;border-top:1px solid #e0e0e0;font-size:0.85rem;color:#666;text-align:center;" role="contentinfo" aria-label="Document timestamp">\n  <p>This accessible document was last updated on ${readableDate}</p>\n</footer>`;
  const bodyCloseIdx = html.lastIndexOf("</body>");
  if (bodyCloseIdx !== -1) {
    html = html.slice(0, bodyCloseIdx) + timestampFooter + "\n" + html.slice(bodyCloseIdx);
  }

  const filename = conversion.originalFilename.replace(/\.pdf$/i, "") + "-accessible.html";
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.send(html);
});

router.get("/conversions/:id/download-docx", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const params = DownloadAccessibleHtmlParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [conversion] = await db
    .select({
      accessibleHtml: conversionsTable.accessibleHtml,
      originalFilename: conversionsTable.originalFilename,
      status: conversionsTable.status,
      updatedAt: conversionsTable.updatedAt,
    })
    .from(conversionsTable)
    .where(and(eq(conversionsTable.id, params.data.id), eq(conversionsTable.userId, req.user.id)));

  if (!conversion) {
    res.status(404).json({ error: "Conversion not found" });
    return;
  }

  if (conversion.status !== "completed" || !conversion.accessibleHtml) {
    res.status(400).json({ error: "Accessible HTML is not yet available" });
    return;
  }

  let html = conversion.accessibleHtml;
  const updatedDate = conversion.updatedAt ? new Date(conversion.updatedAt) : new Date();
  const isoDate = updatedDate.toISOString();
  const readableDate = updatedDate.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  const metaTag = `<meta name="date" content="${isoDate}">`;
  const headCloseIdx = html.indexOf("</head>");
  if (headCloseIdx !== -1) {
    html = html.slice(0, headCloseIdx) + `  ${metaTag}\n` + html.slice(headCloseIdx);
  }

  const timestampFooter = `\n<footer style="margin-top:2rem;padding:1rem 0;border-top:1px solid #e0e0e0;font-size:0.85rem;color:#666;text-align:center;" role="contentinfo" aria-label="Document timestamp">\n  <p>This accessible document was last updated on ${readableDate}</p>\n</footer>`;
  const bodyCloseIdx = html.lastIndexOf("</body>");
  if (bodyCloseIdx !== -1) {
    html = html.slice(0, bodyCloseIdx) + timestampFooter + "\n" + html.slice(bodyCloseIdx);
  }

  const titleMatch = html.match(/<title[^>]*>(.*?)<\/title>/i);
  const docTitle = titleMatch ? titleMatch[1] : conversion.originalFilename.replace(/\.pdf$/i, "");

  const langMatch = html.match(/<html[^>]*\slang=["']([^"']+)["']/i);
  const docLang = langMatch ? langMatch[1] : "en";

  const authorMatch = html.match(/<meta\s+name=["']author["']\s+content=["']([^"']+)["']/i)
    || html.match(/<meta\s+content=["']([^"']+)["']\s+name=["']author["']/i);
  const docAuthor = authorMatch ? authorMatch[1] : "PDF Accessibility Converter";

  try {
    const { buildDocx } = await import("../lib/docx-builder.js");
    const docxBuffer = await buildDocx(html, {
      title: docTitle,
      filename: conversion.originalFilename,
      lang: docLang,
      author: docAuthor,
    });

    const filename = conversion.originalFilename.replace(/\.pdf$/i, "") + "-accessible.docx";
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(docxBuffer);
  } catch (err) {
    console.error("DOCX conversion error:", err);
    res.status(500).json({ error: "Failed to generate DOCX file" });
  }
});

export default router;
