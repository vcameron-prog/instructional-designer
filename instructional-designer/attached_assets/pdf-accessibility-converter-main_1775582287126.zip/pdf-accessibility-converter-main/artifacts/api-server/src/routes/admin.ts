import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { sql, count, eq } from "drizzle-orm";
import { db, usersTable, conversionsTable } from "@workspace/db";

const router: IRouter = Router();

function getAdminUserIds(): string[] {
  const raw = process.env.ADMIN_USER_IDS || "";
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const adminIds = getAdminUserIds();
  if (!adminIds.includes(req.user.id)) {
    res.status(403).json({ error: "Access denied" });
    return;
  }

  next();
}

router.get("/admin/users", requireAdmin, async (_req: Request, res: Response) => {
  const users = await db
    .select({
      id: usersTable.id,
      email: usersTable.email,
      firstName: usersTable.firstName,
      lastName: usersTable.lastName,
      profileImageUrl: usersTable.profileImageUrl,
      createdAt: usersTable.createdAt,
      conversionCount: count(conversionsTable.id),
    })
    .from(usersTable)
    .leftJoin(conversionsTable, eq(usersTable.id, conversionsTable.userId))
    .groupBy(usersTable.id)
    .orderBy(usersTable.createdAt);

  res.json({ users });
});

router.get("/admin/stats", requireAdmin, async (_req: Request, res: Response) => {
  const [userCount] = await db
    .select({ total: count() })
    .from(usersTable);

  const [conversionCount] = await db
    .select({ total: count() })
    .from(conversionsTable);

  const signupsByMonth = await db
    .select({
      month: sql<string>`to_char(${usersTable.createdAt}, 'YYYY-MM')`.as("month"),
      count: count(),
    })
    .from(usersTable)
    .groupBy(sql`to_char(${usersTable.createdAt}, 'YYYY-MM')`)
    .orderBy(sql`to_char(${usersTable.createdAt}, 'YYYY-MM')`);

  const conversionsByMonth = await db
    .select({
      month: sql<string>`to_char(${conversionsTable.createdAt}, 'YYYY-MM')`.as("month"),
      count: count(),
    })
    .from(conversionsTable)
    .groupBy(sql`to_char(${conversionsTable.createdAt}, 'YYYY-MM')`)
    .orderBy(sql`to_char(${conversionsTable.createdAt}, 'YYYY-MM')`);

  res.json({
    totalUsers: userCount.total,
    totalConversions: conversionCount.total,
    signupsByMonth,
    conversionsByMonth,
  });
});

router.get("/admin/check", async (req: Request, res: Response) => {
  if (!req.isAuthenticated()) {
    res.json({ isAdmin: false });
    return;
  }

  const adminIds = getAdminUserIds();
  res.json({ isAdmin: adminIds.includes(req.user.id) });
});

export default router;
