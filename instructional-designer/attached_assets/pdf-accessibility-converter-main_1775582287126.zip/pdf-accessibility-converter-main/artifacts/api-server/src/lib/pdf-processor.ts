import { PDFParse } from "pdf-parse";

export interface ExtractedImage {
  pageNumber: number;
  name: string;
  width: number;
  height: number;
  dataUrl: string;
}

export interface ExtractedTable {
  pageNumber: number;
  rows: string[][];
}

export interface PdfExtraction {
  text: string;
  pageCount: number;
  metadata: {
    title?: string;
    author?: string;
    subject?: string;
    creator?: string;
  };
  images: ExtractedImage[];
  tables: ExtractedTable[];
}

export async function extractPdfContent(buffer: Buffer): Promise<PdfExtraction> {
  const parser = new PDFParse({
    data: new Uint8Array(buffer),
  });

  const textResult = await parser.getText();
  const pageCount = textResult.total;

  let metadata: PdfExtraction["metadata"] = {};
  try {
    const infoResult = await parser.getInfo();
    const info = infoResult.info;
    if (info) {
      metadata = {
        title: info.Title || undefined,
        author: info.Author || undefined,
        subject: info.Subject || undefined,
        creator: info.Creator || undefined,
      };
    }
  } catch {
    // metadata extraction may fail for some PDFs
  }

  const images: ExtractedImage[] = [];
  try {
    const imageResult = await parser.getImage({
      imageDataUrl: true,
      imageBuffer: false,
      imageThreshold: 50,
    });
    for (const page of imageResult.pages) {
      for (const img of page.images) {
        if (img.width > 50 && img.height > 50) {
          images.push({
            pageNumber: page.pageNumber,
            name: img.name,
            width: img.width,
            height: img.height,
            dataUrl: img.dataUrl,
          });
        }
      }
    }
  } catch {
    // image extraction may fail for some PDFs
  }

  const tables: ExtractedTable[] = [];
  try {
    const tableResult = await parser.getTable();
    for (const page of tableResult.pages) {
      for (const table of page.tables) {
        if (table.length > 0) {
          tables.push({
            pageNumber: page.num,
            rows: table,
          });
        }
      }
    }
  } catch {
    // table extraction may fail for some PDFs
  }

  await parser.destroy();

  return {
    text: textResult.text,
    pageCount,
    metadata,
    images,
    tables,
  };
}

export function needsOcr(text: string, pageCount: number): boolean {
  const trimmed = text.replace(/\s+/g, " ").trim();
  const charsPerPage = pageCount > 0 ? trimmed.length / pageCount : 0;
  return charsPerPage < 50;
}

export function findScannedPages(images: ExtractedImage[]): Set<number> {
  const pages = new Set<number>();
  const LARGE_IMAGE_THRESHOLD = 500 * 500;
  for (const img of images) {
    if (img.width * img.height >= LARGE_IMAGE_THRESHOLD) {
      pages.add(img.pageNumber);
    }
  }
  return pages;
}
