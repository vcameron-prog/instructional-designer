import { useParams, Link } from "wouter";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { 
  FileText, Download, ArrowLeft, Loader2, FileCheck2, 
  AlertTriangle, ShieldCheck, Cpu, Code, ChevronDown, Wand2, Info, Upload, LogIn,
  GraduationCap, Share2, Globe, ExternalLink, ClipboardCopy, Check
} from "lucide-react";
import { Layout } from "@/components/Layout";
import { StatusBadge } from "@/components/StatusBadge";
import { ComplianceChart } from "@/components/ComplianceChart";
import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import DOMPurify from "dompurify";
import { 
  useAppConversion, 
  useAppProcessConversion,
  useAppFixIssue,
  useAppAcceptIssue,
  useAppRevertIssue
} from "@/hooks/use-conversions";
import { useAuth } from "@workspace/replit-auth-web";
import { formatBytes, cn } from "@/lib/utils";

export default function ConversionDetail() {
  const { id } = useParams<{ id: string }>();
  const numericId = parseInt(id || "0", 10);
  const { isAuthenticated, isLoading: authLoading, login } = useAuth();
  
  const { data: conversion, isLoading, isError } = useAppConversion(numericId);
  const processMutation = useAppProcessConversion();
  const fixMutation = useAppFixIssue();
  const acceptMutation = useAppAcceptIssue();
  const revertMutation = useAppRevertIssue();
  const [isDownloading, setIsDownloading] = useState(false);
  const [isDownloadingDocx, setIsDownloadingDocx] = useState(false);
  const [expandedIssues, setExpandedIssues] = useState<Set<string>>(new Set());
  const [fixingIndex, setFixingIndex] = useState<number | null>(null);
  const [acceptingIndex, setAcceptingIndex] = useState<number | null>(null);
  const [revertingIndex, setRevertingIndex] = useState<number | null>(null);
  const [justificationText, setJustificationText] = useState("");
  const [showAcceptForm, setShowAcceptForm] = useState<number | null>(null);
  const [activeInstructionTab, setActiveInstructionTab] = useState<"blackboard" | "share" | "website">("blackboard");
  const [copyState, setCopyState] = useState<"idle" | "copying" | "copied" | "error">("idle");

  const sanitizedHtml = useMemo(() => {
    if (!conversion?.accessibleHtml) return "";
    return DOMPurify.sanitize(conversion.accessibleHtml, {
      ADD_TAGS: ["main", "nav", "header", "footer", "section", "article", "aside", "figure", "figcaption"],
      ADD_ATTR: ["role", "aria-label", "aria-labelledby", "aria-describedby", "aria-hidden", "tabindex", "lang", "scope"],
    });
  }, [conversion?.accessibleHtml]);

  const issueKey = useCallback((issue: { criterion: string; title: string }) => 
    `${issue.criterion}::${issue.title}`, []);

  const toggleIssue = useCallback((key: string) => {
    setExpandedIssues(prev => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  }, []);

  const autoStartedForIdRef = useRef<number | null>(null);

  useEffect(() => {
    if (
      conversion?.status === 'uploaded' &&
      !processMutation.isPending &&
      autoStartedForIdRef.current !== numericId
    ) {
      autoStartedForIdRef.current = numericId;
      processMutation.mutate({ id: numericId });
    }
  }, [conversion?.status, processMutation.isPending, numericId]);

  const [fixError, setFixError] = useState<string | null>(null);

  const handleFixIssue = useCallback((issueIndex: number) => {
    setFixingIndex(issueIndex);
    setFixError(null);
    fixMutation.mutate(
      { id: numericId, data: { issueIndex } },
      {
        onError: () => {
          setFixError("Failed to fix this issue. Please try again.");
        },
        onSettled: () => {
          setFixingIndex(null);
        },
      }
    );
  }, [fixMutation, numericId]);

  const handleAcceptIssue = useCallback((issueIndex: number) => {
    if (!justificationText.trim()) return;
    setAcceptingIndex(issueIndex);
    setFixError(null);
    acceptMutation.mutate(
      { id: numericId, data: { issueIndex, justification: justificationText.trim() } },
      {
        onError: () => {
          setFixError("Failed to accept this issue. Please try again.");
        },
        onSettled: () => {
          setAcceptingIndex(null);
          setShowAcceptForm(null);
          setJustificationText("");
        },
      }
    );
  }, [acceptMutation, numericId, justificationText]);

  const handleRevertIssue = useCallback((issueIndex: number) => {
    setRevertingIndex(issueIndex);
    setFixError(null);
    revertMutation.mutate(
      { id: numericId, data: { issueIndex } },
      {
        onError: () => {
          setFixError("Failed to revert this issue. Please try again.");
        },
        onSettled: () => {
          setRevertingIndex(null);
        },
      }
    );
  }, [revertMutation, numericId]);

  if (!authLoading && !isAuthenticated) {
    return (
      <Layout>
        <div className="bg-card border border-border rounded-3xl p-16 text-center shadow-sm max-w-xl mx-auto mt-12">
          <LogIn className="w-16 h-16 mx-auto text-muted-foreground mb-4 opacity-50" aria-hidden="true" />
          <h1 className="text-xl font-bold text-foreground">Log in to view this document</h1>
          <p className="text-muted-foreground mt-2 max-w-md mx-auto mb-8">
            Please log in to access conversion details and download accessible files.
          </p>
          <button
            onClick={login}
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-bold shadow-md shadow-primary/20 hover:-translate-y-0.5 transition-all"
          >
            <LogIn className="w-5 h-5" aria-hidden="true" />
            Log in
          </button>
        </div>
      </Layout>
    );
  }

  if (isLoading || authLoading) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center py-32 text-muted-foreground" role="status" aria-live="polite">
          <Loader2 className="w-10 h-10 animate-spin text-primary mb-4" aria-hidden="true" />
          <p className="text-lg font-medium">Loading document details...</p>
        </div>
      </Layout>
    );
  }

  if (isError || !conversion) {
    return (
      <Layout>
        <div className="bg-destructive/10 border border-destructive/20 text-destructive p-8 rounded-3xl text-center max-w-xl mx-auto mt-12" role="alert">
          <AlertTriangle className="w-12 h-12 mx-auto mb-4 opacity-80" aria-hidden="true" />
          <h1 className="text-2xl font-bold">Document Not Found</h1>
          <p className="mt-2 text-destructive/80 mb-6">This conversion record may have been deleted or does not exist.</p>
          <Link href="/history" className="inline-flex items-center gap-2 px-6 py-3 bg-destructive text-destructive-foreground rounded-xl font-bold hover:opacity-90 transition-opacity">
            <ArrowLeft className="w-4 h-4" aria-hidden="true" /> Back to History
          </Link>
        </div>
      </Layout>
    );
  }

  const handleProcess = () => {
    processMutation.mutate({ id: numericId });
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const baseUrl = import.meta.env.BASE_URL.replace(/\/$/, "");
      const resp = await fetch(`${baseUrl}/api/conversions/${numericId}/download`, {
        credentials: "include",
      });
      if (!resp.ok) return;
      const html = await resp.text();
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = conversion.originalFilename.replace(/\.pdf$/i, '') + '-accessible.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyHtml = async () => {
    if (!conversion?.accessibleHtml) return;
    setCopyState("copying");
    try {
      await navigator.clipboard.writeText(conversion.accessibleHtml);
      setCopyState("copied");
      setTimeout(() => setCopyState("idle"), 2000);
    } catch {
      setCopyState("error");
      setTimeout(() => setCopyState("idle"), 2000);
    }
  };

  const handleDownloadDocx = async () => {
    setIsDownloadingDocx(true);
    try {
      const baseUrl = import.meta.env.BASE_URL.replace(/\/$/, "");
      const resp = await fetch(`${baseUrl}/api/conversions/${numericId}/download-docx`, {
        credentials: "include",
      });
      if (!resp.ok) return;
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = conversion.originalFilename.replace(/\.pdf$/i, '') + '-accessible.docx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } finally {
      setIsDownloadingDocx(false);
    }
  };

  const report = conversion.complianceReport;
  const originalReport = conversion.originalComplianceReport;
  const improvement = report && originalReport ? report.overallScore - originalReport.overallScore : null;

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <Link href="/history" className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" aria-hidden="true" /> Back to History
          </Link>
          
          <div className="bg-card border border-border shadow-sm rounded-3xl p-6 md:p-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 text-primary p-4 rounded-2xl" aria-hidden="true">
                  <FileText className="w-8 h-8" />
                </div>
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold text-foreground break-all">
                    {conversion.originalFilename}
                  </h1>
                  <div className="flex flex-wrap items-center gap-3 mt-3 text-sm text-muted-foreground font-medium">
                    <StatusBadge status={conversion.status === 'completed' && conversion.complianceReport && conversion.complianceReport.overallScore < 100 ? 'review' : conversion.status} />
                    <span aria-hidden="true">•</span>
                    <span>{formatBytes(conversion.fileSize)}</span>
                    {conversion.pageCount && (
                      <>
                        <span aria-hidden="true">•</span>
                        <span>{conversion.pageCount} Pages</span>
                      </>
                    )}
                    <span aria-hidden="true">•</span>
                    <time dateTime={new Date(conversion.createdAt).toISOString()}>
                      {format(new Date(conversion.createdAt), "MMM d, yyyy")}
                    </time>
                    {conversion.updatedAt && new Date(conversion.updatedAt).getTime() - new Date(conversion.createdAt).getTime() > 1000 && (
                      <>
                        <span aria-hidden="true">•</span>
                        <span className="text-xs bg-muted px-2 py-0.5 rounded-full">
                          Last updated {format(new Date(conversion.updatedAt), "MMM d, yyyy 'at' h:mm a")}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                {(conversion.status === 'failed' || (conversion.status === 'uploaded' && processMutation.isError)) && (
                  <button
                    onClick={() => {
                      autoStartedForIdRef.current = null;
                      handleProcess();
                    }}
                    disabled={processMutation.isPending}
                    className="flex-1 md:flex-none inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-bold shadow-md hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                  >
                    {processMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" aria-hidden="true" /> : <Cpu className="w-5 h-5" aria-hidden="true" />}
                    Retry AI Remediation
                  </button>
                )}
                
                {conversion.status === 'completed' && (
                  <>
                    <button
                      onClick={handleDownloadDocx}
                      disabled={isDownloadingDocx}
                      className="flex-1 md:flex-none inline-flex items-center justify-center gap-2 px-6 py-3 bg-success text-success-foreground rounded-xl font-bold shadow-md shadow-success/20 hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                    >
                      {isDownloadingDocx ? <Loader2 className="w-5 h-5 animate-spin" aria-hidden="true" /> : <FileText className="w-5 h-5" aria-hidden="true" />}
                      Download Word (.docx)
                    </button>
                    <button
                      onClick={handleDownload}
                      disabled={isDownloading}
                      className="flex-1 md:flex-none inline-flex items-center justify-center gap-2 px-6 py-3 bg-secondary text-secondary-foreground rounded-xl font-bold shadow-sm hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                    >
                      {isDownloading ? <Loader2 className="w-5 h-5 animate-spin" aria-hidden="true" /> : <Download className="w-5 h-5" aria-hidden="true" />}
                      Download HTML
                    </button>
                    <button
                      onClick={handleCopyHtml}
                      disabled={copyState === "copying"}
                      className="flex-1 md:flex-none inline-flex items-center justify-center gap-2 px-6 py-3 bg-secondary text-secondary-foreground rounded-xl font-bold shadow-sm hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                    >
                      {copyState === "copying" ? <Loader2 className="w-5 h-5 animate-spin" aria-hidden="true" /> : copyState === "copied" ? <Check className="w-5 h-5 text-success" aria-hidden="true" /> : <ClipboardCopy className="w-5 h-5" aria-hidden="true" />}
                      {copyState === "copied" ? "Copied!" : copyState === "error" ? "Copy failed" : "Copy HTML"}
                    </button>
                    <Link
                      href="/"
                      className="flex-1 md:flex-none inline-flex items-center justify-center gap-2 px-6 py-3 bg-secondary text-secondary-foreground rounded-xl font-bold shadow-sm hover:-translate-y-0.5 transition-all"
                    >
                      <Upload className="w-5 h-5" aria-hidden="true" />
                      Convert Another
                    </Link>
                  </>
                )}
              </div>
            </div>

            {conversion.status === 'completed' && (
              <div className="mt-6 bg-secondary/50 border border-border rounded-2xl p-5">
                <div className="flex items-start gap-3 mb-4">
                  <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" aria-hidden="true" />
                  <h2 className="font-bold text-foreground">What to do with your accessible file</h2>
                </div>

                <div
                  className="flex gap-1 mb-4 bg-background/60 rounded-xl p-1"
                  role="tablist"
                  aria-label="File usage instructions"
                  onKeyDown={(e) => {
                    const tabs: Array<"blackboard" | "share" | "website"> = ["blackboard", "share", "website"];
                    const currentIndex = tabs.indexOf(activeInstructionTab);
                    let newIndex = currentIndex;
                    if (e.key === "ArrowRight") newIndex = (currentIndex + 1) % tabs.length;
                    else if (e.key === "ArrowLeft") newIndex = (currentIndex - 1 + tabs.length) % tabs.length;
                    else if (e.key === "Home") newIndex = 0;
                    else if (e.key === "End") newIndex = tabs.length - 1;
                    else return;
                    e.preventDefault();
                    setActiveInstructionTab(tabs[newIndex]);
                    const el = document.getElementById(`tab-${tabs[newIndex]}`);
                    el?.focus();
                  }}
                >
                  <button
                    id="tab-blackboard"
                    role="tab"
                    aria-selected={activeInstructionTab === "blackboard"}
                    aria-controls="tab-panel-blackboard"
                    tabIndex={activeInstructionTab === "blackboard" ? 0 : -1}
                    onClick={() => setActiveInstructionTab("blackboard")}
                    className={cn(
                      "flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all",
                      activeInstructionTab === "blackboard"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground hover:bg-background"
                    )}
                  >
                    <GraduationCap className="w-4 h-4" aria-hidden="true" />
                    <span className="hidden sm:inline">Upload to</span> Blackboard
                  </button>
                  <button
                    id="tab-share"
                    role="tab"
                    aria-selected={activeInstructionTab === "share"}
                    aria-controls="tab-panel-share"
                    tabIndex={activeInstructionTab === "share" ? 0 : -1}
                    onClick={() => setActiveInstructionTab("share")}
                    className={cn(
                      "flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all",
                      activeInstructionTab === "share"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground hover:bg-background"
                    )}
                  >
                    <Share2 className="w-4 h-4" aria-hidden="true" />
                    Share Directly
                  </button>
                  <button
                    id="tab-website"
                    role="tab"
                    aria-selected={activeInstructionTab === "website"}
                    aria-controls="tab-panel-website"
                    tabIndex={activeInstructionTab === "website" ? 0 : -1}
                    onClick={() => setActiveInstructionTab("website")}
                    className={cn(
                      "flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all",
                      activeInstructionTab === "website"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground hover:bg-background"
                    )}
                  >
                    <Globe className="w-4 h-4" aria-hidden="true" />
                    <span className="hidden sm:inline">Host on</span> Website
                  </button>
                </div>

                <div id="tab-panel-blackboard" role="tabpanel" aria-labelledby="tab-blackboard" className={cn("space-y-3", activeInstructionTab !== "blackboard" && "hidden")}>
                  <p className="text-xs font-semibold text-foreground uppercase tracking-wide mb-2">Method 1: Upload Word Document (Recommended)</p>
                  <ol className="space-y-3 text-sm">
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">1</span>
                      <span className="text-muted-foreground pt-0.5">Click the green <span className="font-semibold text-success">"Download Word (.docx)"</span> button above to save the file to your computer.</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">2</span>
                      <span className="text-muted-foreground pt-0.5">Log in to Blackboard and open your course.</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">3</span>
                      <span className="text-muted-foreground pt-0.5">In Course Content, click the <span className="font-semibold text-foreground">+</span> button.</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">4</span>
                      <span className="text-muted-foreground pt-0.5">Click <span className="font-semibold text-foreground">Upload</span>. Upload the .docx file — the same way you'd upload a syllabus or any other document.</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">5</span>
                      <span className="text-muted-foreground pt-0.5">Click <span className="font-semibold text-foreground">Save</span> and make the file visible to students.</span>
                    </li>
                  </ol>

                  <div className="border-t border-border/50 mt-4 pt-4">
                    <p className="text-xs font-semibold text-foreground uppercase tracking-wide mb-2">Method 2: Paste HTML Inline (Alternative)</p>
                    <ol className="space-y-3 text-sm">
                      <li className="flex gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-violet-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">1</span>
                        <span className="text-muted-foreground pt-0.5">Click the <span className="font-semibold text-foreground">"Copy HTML"</span> button above to copy the accessible content to your clipboard.</span>
                      </li>
                      <li className="flex gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-violet-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">2</span>
                        <span className="text-muted-foreground pt-0.5">In Blackboard Ultra, go to <span className="font-semibold text-foreground">Course Content</span> and click the <span className="font-semibold text-foreground">+</span> button.</span>
                      </li>
                      <li className="flex gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-violet-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">3</span>
                        <span className="text-muted-foreground pt-0.5">Select <span className="font-semibold text-foreground">"Create"</span> and then <span className="font-semibold text-foreground">"Document"</span> to create a new content item.</span>
                      </li>
                      <li className="flex gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-violet-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">4</span>
                        <span className="text-muted-foreground pt-0.5">In <span className="font-semibold text-foreground">"Select a Type of Content to Add a Block"</span> click the <span className="font-semibold text-foreground">"HTML"</span> button (the <code className="px-1 py-0.5 bg-muted rounded text-xs font-mono">&lt;/&gt;</code> icon) to switch to HTML view.</span>
                      </li>
                      <li className="flex gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-violet-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">5</span>
                        <span className="text-muted-foreground pt-0.5">Paste the copied HTML and click <span className="font-semibold text-foreground">Save</span>, no file download needed.</span>
                      </li>
                      <li className="flex gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-violet-600 text-white flex items-center justify-center text-xs font-bold" aria-hidden="true">6</span>
                        <span className="text-muted-foreground pt-0.5">Make the document visible to your students; students will see the accessible content inline.</span>
                      </li>
                    </ol>
                  </div>
                  <div className="pt-2 border-t border-border/50 mt-3">
                    <a
                      href="https://help.anthology.com/blackboard/instructor/en/course-and-content-management/add-content/add-a-file/supported-file-types.html"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                      Need more help? See Blackboard's supported file types guide
                    </a>
                  </div>
                </div>

                <div id="tab-panel-share" role="tabpanel" aria-labelledby="tab-share" className={cn("space-y-3", activeInstructionTab !== "share" && "hidden")}>
                  <ul className="space-y-3 text-sm">
                    <li className="flex gap-3 items-start">
                      <span className="flex-shrink-0 w-1.5 h-1.5 rounded-full bg-blue-600 mt-2" aria-hidden="true" />
                      <span className="text-muted-foreground">Download the <span className="font-semibold text-foreground">Word (.docx)</span> file and share it — recipients can open it in Word, Google Docs, or any office suite.</span>
                    </li>
                    <li className="flex gap-3 items-start">
                      <span className="flex-shrink-0 w-1.5 h-1.5 rounded-full bg-blue-600 mt-2" aria-hidden="true" />
                      <span className="text-muted-foreground">Email it, share via <span className="font-semibold text-foreground">Google Drive</span>, <span className="font-semibold text-foreground">OneDrive</span>, or any file sharing service.</span>
                    </li>
                    <li className="flex gap-3 items-start">
                      <span className="flex-shrink-0 w-1.5 h-1.5 rounded-full bg-blue-600 mt-2" aria-hidden="true" />
                      <span className="text-muted-foreground">The <span className="font-semibold text-foreground">HTML version</span> is also available if you need a file that opens directly in a web browser.</span>
                    </li>
                  </ul>
                </div>

                <div id="tab-panel-website" role="tabpanel" aria-labelledby="tab-website" className={cn("space-y-3", activeInstructionTab !== "website" && "hidden")}>
                  <p className="text-sm text-muted-foreground">
                    Use the <span className="font-semibold text-foreground">HTML download</span> to upload the file to your web server, replacing the original PDF with an accessible version. This is ideal if you maintain a department or course website.
                  </p>
                  <p className="text-xs text-muted-foreground/70">
                    This option is best suited for users who manage their own web hosting. If you're not sure, the Blackboard or Share options above are easier.
                  </p>
                </div>
              </div>
            )}
            
            {(conversion.status === 'uploaded' || conversion.status === 'processing') && (
              <div className="mt-8 pt-8 border-t" role="status" aria-live="polite">
                <div className="flex items-center justify-between mb-4">
                  <span className="font-bold flex items-center gap-2 text-primary">
                    <Loader2 className="w-5 h-5 animate-spin" aria-hidden="true" />
                    {conversion.status === 'uploaded' ? 'Preparing Document' : 'AI Remediation in Progress'}
                  </span>
                  <span className="text-sm font-semibold text-muted-foreground animate-pulse">
                    {conversion.status === 'uploaded' ? 'Starting remediation...' : 'Analyzing document structure...'}
                  </span>
                </div>
                <div className="h-3 w-full bg-secondary rounded-full overflow-hidden" role="progressbar" aria-label="Remediation progress">
                  <div className="h-full bg-primary rounded-full animate-[progress_2s_ease-in-out_infinite] w-1/3 origin-left"></div>
                </div>
                <p className="mt-4 text-sm text-muted-foreground text-center">
                  {conversion.status === 'uploaded'
                    ? 'Your document is being prepared for AI remediation. Processing will begin shortly.'
                    : 'Our AI is currently analyzing layout, extracting text, generating image alt text, and restructuring into WCAG 2.1 AA HTML. This may take a minute for large documents.'}
                </p>
              </div>
            )}
            
            {conversion.status === 'failed' && (
              <div className="mt-8 pt-8 border-t">
                <div className="bg-destructive/10 border border-destructive/20 text-destructive p-5 rounded-xl flex items-start gap-4" role="alert">
                  <AlertTriangle className="w-6 h-6 flex-shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <h2 className="font-bold">Remediation Failed</h2>
                    <p className="text-sm mt-1">{conversion.errorMessage || "An unknown error occurred during AI processing. Please try uploading the document again."}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {conversion.status === 'completed' && report && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-6"
          >
            <div className="lg:col-span-1 space-y-6">
              <section className="bg-card border border-border shadow-sm rounded-3xl p-6" aria-labelledby="compliance-score-heading">
                <div className="flex items-center gap-3 mb-6 pb-4 border-b">
                  <ShieldCheck className="w-6 h-6 text-primary" aria-hidden="true" />
                  <h2 id="compliance-score-heading" className="text-xl font-bold">Compliance Score</h2>
                </div>

                {originalReport && (
                  <div className="flex items-center justify-between gap-4 mb-6">
                    <div className="flex flex-col items-center flex-1">
                      <p className="text-xs font-bold text-muted-foreground uppercase mb-2">Before</p>
                      <div className="relative flex items-center justify-center w-24 h-24 mb-1" role="img" aria-label={`Original score: ${originalReport.overallScore} out of 100`}>
                        <svg className="w-full h-full transform -rotate-90" aria-hidden="true">
                          <circle cx="48" cy="48" r="40" fill="transparent" stroke="currentColor" strokeWidth="8" className="text-secondary" />
                          <circle
                            cx="48" cy="48" r="40" fill="transparent" stroke="currentColor" strokeWidth="8"
                            strokeDasharray={`${2 * Math.PI * 40}`}
                            strokeDashoffset={`${2 * Math.PI * 40 * (1 - originalReport.overallScore / 100)}`}
                            className={cn("transition-all duration-1000", originalReport.overallScore >= 90 ? "text-success" : originalReport.overallScore >= 70 ? "text-warning" : "text-destructive")}
                          />
                        </svg>
                        <span className="absolute text-xl font-black" aria-hidden="true">{originalReport.overallScore}</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                      <ArrowLeft className="w-5 h-5 text-muted-foreground rotate-180" aria-hidden="true" />
                      {improvement !== null && (
                        <span className={cn("text-sm font-black", improvement > 0 ? "text-success" : "text-muted-foreground")}>
                          {improvement > 0 ? `+${improvement}` : improvement}
                        </span>
                      )}
                    </div>
                    <div className="flex flex-col items-center flex-1">
                      <p className="text-xs font-bold text-primary uppercase mb-2">After</p>
                      <div className="relative flex items-center justify-center w-24 h-24 mb-1" role="img" aria-label={`Converted score: ${report.overallScore} out of 100`}>
                        <svg className="w-full h-full transform -rotate-90" aria-hidden="true">
                          <circle cx="48" cy="48" r="40" fill="transparent" stroke="currentColor" strokeWidth="8" className="text-secondary" />
                          <circle
                            cx="48" cy="48" r="40" fill="transparent" stroke="currentColor" strokeWidth="8"
                            strokeDasharray={`${2 * Math.PI * 40}`}
                            strokeDashoffset={`${2 * Math.PI * 40 * (1 - report.overallScore / 100)}`}
                            className={cn("transition-all duration-1000", report.overallScore >= 90 ? "text-success" : report.overallScore >= 70 ? "text-warning" : "text-destructive")}
                          />
                        </svg>
                        <span className="absolute text-xl font-black" aria-hidden="true">{report.overallScore}</span>
                      </div>
                    </div>
                  </div>
                )}

                {!originalReport && (
                  <div className="flex flex-col items-center mb-6">
                    <div className="relative flex items-center justify-center w-32 h-32 mb-2" role="img" aria-label={`Compliance score: ${report.overallScore} out of 100`}>
                      <svg className="w-full h-full transform -rotate-90" aria-hidden="true">
                        <circle cx="64" cy="64" r="56" fill="transparent" stroke="currentColor" strokeWidth="12" className="text-secondary" />
                        <circle
                          cx="64" cy="64" r="56" fill="transparent" stroke="currentColor" strokeWidth="12"
                          strokeDasharray={`${2 * Math.PI * 56}`}
                          strokeDashoffset={`${2 * Math.PI * 56 * (1 - report.overallScore / 100)}`}
                          className={cn("transition-all duration-1000", report.overallScore >= 90 ? "text-success" : report.overallScore >= 70 ? "text-warning" : "text-destructive")}
                        />
                      </svg>
                      <span className="absolute text-3xl font-black" aria-hidden="true">{report.overallScore}</span>
                    </div>
                    <p className="font-semibold text-muted-foreground">WCAG 2.1 Level AA</p>
                  </div>
                )}
                
                <ComplianceChart report={report} />
                
                <div className="grid grid-cols-2 gap-3 mt-6">
                  <div className="bg-success/10 border border-success/20 p-3 rounded-xl text-center">
                    <p className="text-2xl font-black text-success">{report.passCount}</p>
                    <p className="text-xs font-bold text-success/80 uppercase">Passed</p>
                  </div>
                  <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl text-center">
                    <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{report.fixedCount}</p>
                    <p className="text-xs font-bold text-emerald-600/80 dark:text-emerald-400/80 uppercase">AI Fixed</p>
                  </div>
                  <div className="bg-warning/10 border border-warning/20 p-3 rounded-xl text-center">
                    <p className="text-2xl font-black text-warning">{report.warningCount}</p>
                    <p className="text-xs font-bold text-warning/80 uppercase">Warnings</p>
                  </div>
                  <div className="bg-destructive/10 border border-destructive/20 p-3 rounded-xl text-center">
                    <p className="text-2xl font-black text-destructive">{report.failCount}</p>
                    <p className="text-xs font-bold text-destructive/80 uppercase">Failed</p>
                  </div>
                  <div className="col-span-2 bg-violet-500/10 border border-violet-500/20 p-3 rounded-xl text-center">
                    <p className="text-2xl font-black text-violet-600 dark:text-violet-400">{report.acceptedCount ?? 0}</p>
                    <p className="text-xs font-bold text-violet-600/80 dark:text-violet-400/80 uppercase">Accepted</p>
                  </div>
                </div>
              </section>
            </div>

            <div className="lg:col-span-2 space-y-6">
              
              {conversion.accessibleHtml && (
                <section className="bg-card border border-border shadow-sm rounded-3xl overflow-hidden flex flex-col" aria-labelledby="html-preview-heading">
                  <div className="bg-secondary/50 border-b px-6 py-4 flex items-center justify-between">
                    <h2 id="html-preview-heading" className="flex items-center gap-2 text-foreground font-bold">
                      <Code className="w-5 h-5" aria-hidden="true" />
                      Accessible HTML Preview
                    </h2>
                  </div>
                  <div className="p-6 bg-card max-h-[500px] overflow-y-auto" tabIndex={0} role="region" aria-label="Accessible HTML output preview">
                    <div 
                      className="prose prose-slate max-w-none dark:prose-invert 
                        prose-headings:font-serif prose-headings:text-primary 
                        prose-a:text-info prose-a:underline
                        prose-img:rounded-xl prose-img:border prose-img:shadow-sm"
                      dangerouslySetInnerHTML={{ __html: sanitizedHtml }} 
                    />
                  </div>
                </section>
              )}

              <section className="bg-card border border-border shadow-sm rounded-3xl p-6" aria-labelledby="audit-details-heading">
                <div className="flex items-center gap-2 mb-6 border-b pb-4">
                  <FileCheck2 className="w-6 h-6 text-blue-600 dark:text-blue-400" aria-hidden="true" />
                  <h2 id="audit-details-heading" className="text-xl font-bold">Audit Details</h2>
                </div>
                
                {fixError && (
                  <div role="alert" className="mb-4 p-3 bg-destructive/10 text-destructive rounded-lg text-sm font-medium">
                    {fixError}
                  </div>
                )}

                <div className="space-y-3">
                  {report.issues.map((issue, i) => {
                    const key = issueKey(issue);
                    const isExpanded = expandedIssues.has(key);
                    const isFixable = issue.status === "fail" || issue.status === "warning";
                    const isFixing = fixingIndex === i;
                    
                    return (
                      <div key={key} className={cn(
                        "rounded-2xl border bg-background transition-all",
                        isExpanded ? "border-primary/30 shadow-sm" : "hover:border-primary/20"
                      )}>
                        <button
                          onClick={() => toggleIssue(key)}
                          className="w-full flex items-center gap-3 p-4 text-left cursor-pointer"
                          aria-expanded={isExpanded}
                          aria-controls={`issue-detail-${i}`}
                        >
                          <div className="flex-shrink-0">
                            <StatusBadge status={issue.status} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="font-bold text-foreground text-sm">{issue.title}</h3>
                              <span className="text-xs font-mono bg-secondary text-secondary-foreground px-2 py-0.5 rounded font-bold">
                                WCAG {issue.criterion} ({issue.level})
                              </span>
                            </div>
                          </div>
                          <ChevronDown 
                            className={cn(
                              "w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform duration-200",
                              isExpanded && "rotate-180"
                            )} 
                            aria-hidden="true" 
                          />
                        </button>
                        
                        <AnimatePresence>
                          {isExpanded && (
                            <motion.div
                              id={`issue-detail-${i}`}
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.2 }}
                              className="overflow-hidden"
                            >
                              <div className="px-4 pb-4 space-y-3 border-t pt-3">
                                <p className="text-sm text-muted-foreground">{issue.description}</p>
                                {issue.status === "accepted" && issue.justification && (
                                  <div className="bg-violet-500/5 border border-violet-500/20 rounded-lg p-3">
                                    <p className="text-xs font-bold text-violet-600 dark:text-violet-400 uppercase mb-1">Justification</p>
                                    <p className="text-sm text-muted-foreground">{issue.justification}</p>
                                  </div>
                                )}
                                {isFixable && (
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <button
                                      onClick={() => handleFixIssue(i)}
                                      disabled={isFixing || fixingIndex !== null || acceptingIndex !== null}
                                      className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-bold shadow-sm hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                                    >
                                      {isFixing ? (
                                        <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                                      ) : (
                                        <Wand2 className="w-4 h-4" aria-hidden="true" />
                                      )}
                                      {isFixing ? "Fixing..." : "Fix with AI"}
                                    </button>
                                    {showAcceptForm !== i && (
                                      <button
                                        onClick={() => { setShowAcceptForm(i); setJustificationText(""); }}
                                        disabled={fixingIndex !== null || acceptingIndex !== null}
                                        className="inline-flex items-center gap-2 px-4 py-2 bg-violet-500/10 text-violet-600 dark:text-violet-400 border border-violet-500/20 rounded-lg text-sm font-bold hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                                      >
                                        Mark as Accepted
                                      </button>
                                    )}
                                  </div>
                                )}
                                {showAcceptForm === i && isFixable && (
                                  <div className="space-y-2">
                                    <label className="block text-xs font-bold text-muted-foreground uppercase">
                                      Why can't this be fixed?
                                    </label>
                                    <textarea
                                      value={justificationText}
                                      onChange={(e) => setJustificationText(e.target.value)}
                                      placeholder="Explain why this issue cannot be resolved..."
                                      className="w-full p-3 border border-border rounded-lg text-sm bg-background resize-none focus:outline-none focus:ring-2 focus:ring-violet-500/40"
                                      rows={3}
                                    />
                                    <div className="flex items-center gap-2">
                                      <button
                                        onClick={() => handleAcceptIssue(i)}
                                        disabled={!justificationText.trim() || acceptingIndex !== null}
                                        className="inline-flex items-center gap-2 px-4 py-2 bg-violet-600 text-white rounded-lg text-sm font-bold shadow-sm hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                                      >
                                        {acceptingIndex === i ? (
                                          <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                                        ) : null}
                                        {acceptingIndex === i ? "Accepting..." : "Confirm"}
                                      </button>
                                      <button
                                        onClick={() => { setShowAcceptForm(null); setJustificationText(""); }}
                                        className="px-4 py-2 text-sm font-bold text-muted-foreground hover:text-foreground transition-colors"
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  </div>
                                )}
                                {issue.status === "accepted" && (
                                  <button
                                    onClick={() => handleRevertIssue(i)}
                                    disabled={revertingIndex !== null}
                                    className="inline-flex items-center gap-2 px-4 py-2 bg-secondary text-secondary-foreground border border-border rounded-lg text-sm font-bold hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                                  >
                                    {revertingIndex === i ? (
                                      <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                                    ) : null}
                                    {revertingIndex === i ? "Reverting..." : "Undo Acceptance"}
                                  </button>
                                )}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              </section>
            </div>
          </motion.div>
        )}
      </div>
    </Layout>
  );
}
