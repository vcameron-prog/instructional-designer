#!/bin/bash
set -e
pnpm install --frozen-lockfile
pnpm --filter db push
pnpm --filter @workspace/api-zod exec tsc -p tsconfig.json
pnpm --filter @workspace/api-client-react exec tsc -p tsconfig.json
pnpm --filter @workspace/db exec tsc -p tsconfig.json
pnpm --filter @workspace/replit-auth-web exec tsc -p tsconfig.json
